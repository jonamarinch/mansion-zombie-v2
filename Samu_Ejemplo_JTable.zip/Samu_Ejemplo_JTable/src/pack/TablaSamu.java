package pack;
 
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
 
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;
import javax.swing.JDialog;
 
import java.awt.Color;
import java.awt.Cursor;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
 
public class TablaSamu extends JFrame implements ActionListener {
 
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JButton btnAñadirLibro;
	private JButton btnGuardar;
	private JButton btnCargarEnFichero;
//	private JTable tblInformacion;
	private JScrollPane scroll;
	private JLabel lblTitulo, lblAutor, lblAño;
	private JButton btnGuardarLibro;
	private JTextField textTitulo;
	private JTextField textAño;
	private JTextField textAutor;
	private Libro[] vLibros;
	private final int MAX_LIBROS = 10;
	private final String RUTA_FICHERO = "src"+File.separator+"Ejercicio_2"+File.separator+"datosGuardados";
 
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TablaSamu frame = new TablaSamu();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
 
	/**
	 * Create the frame.
	 */
	public TablaSamu() {
		this.vLibros = new Libro[MAX_LIBROS];
		this.mostrarInterfaz();
	}
	/**
	 * Interfaz principal del ejercicio
	 */
	public void mostrarInterfaz() {
		setTitle("Libros");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 128, 128));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
 
		setContentPane(contentPane);
		contentPane.setLayout(null);
		btnAñadirLibro = new JButton("Añadir Libro");
		btnAñadirLibro.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnAñadirLibro.setBounds(10, 216, 127, 34);
		btnAñadirLibro.addActionListener(this);
		contentPane.add(btnAñadirLibro);
		btnGuardar = new JButton("Guardar");
		btnGuardar.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnGuardar.setBounds(162, 216, 117, 34);
		btnGuardar.addActionListener(this);
		contentPane.add(btnGuardar);
		btnCargarEnFichero = new JButton("Cargar");
		btnCargarEnFichero.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnCargarEnFichero.setBounds(307, 216, 117, 34);
		btnCargarEnFichero.addActionListener(this);
		contentPane.add(btnCargarEnFichero);
		tblInformacion = new JTable();
		tblInformacion.setBounds(10, 11, 414, 194);
		scroll = new JScrollPane(tblInformacion);
		scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
		scroll.setBounds(10, 11, 414, 194);
		contentPane.add(scroll);
	}
 
	/**
	 * Listener que se encarga del manejo de las acciones de los botones
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		// Antes de abir la ventana para añadir libros tendrá que verificar que el vector no esté lleno
		if(e.getSource() == btnAñadirLibro) {
			if(!vectorLleno()) {
				agregarLibro();
			}else {
				// Mensaje que le mostrará al usuario en caso de que el vector esté lleno
				JOptionPane.showMessageDialog(null, "Cantidad máxima alcanzada", "No puedes agregar más", JOptionPane.ERROR_MESSAGE);
			}
		}else if(e.getSource() == btnGuardar) {
			escribirLibros(RUTA_FICHERO);
		}else if(e.getSource() == btnCargarEnFichero) {
			leerLibros(RUTA_FICHERO);
		}
		if(e.getSource() == btnGuardarLibro) {
			libroAgregado();
		}
	}
	/**
	 * Ventana secundaría que se abrirá cuando se quiera añadir un libro, permitiendole al usuario ingresar datos.
	 */
	public void agregarLibro() {
		JDialog dialog = new JDialog(this,"Añadir libro",true);
		dialog.setBounds(100, 100, 450, 300);
		dialog.getContentPane().setLayout(null);	
		lblTitulo = new JLabel("Titulo");
		lblTitulo.setBounds(10, 40, 86, 57);
		dialog.getContentPane().add(lblTitulo);
		lblAutor = new JLabel("Autor");
		lblAutor.setBounds(10, 100, 86, 57);
		dialog.getContentPane().add(lblAutor);
		lblAño = new JLabel("Año");
		lblAño.setBounds(10, 160, 86, 57);
		dialog.getContentPane().add(lblAño);
		textTitulo = new JTextField();
		textTitulo.setBounds(149, 40, 227, 20);
		dialog.getContentPane().add(textTitulo);
		textAutor = new JTextField();
		textAutor.setBounds(149, 100, 227, 20);
		dialog.getContentPane().add(textAutor);
		textAño = new JTextField();
		textAño.setBounds(149, 160, 227, 20);
		dialog.getContentPane().add(textAño);
		btnGuardarLibro = new JButton("Guardar");
		btnGuardarLibro.setBounds(294, 209, 130, 41);
		btnGuardarLibro.addActionListener(this);
		dialog.getContentPane().add(btnGuardarLibro);
		dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		dialog.setVisible(true);
	}
	/**
	 * Método que se encarga de agregar la información ingresada por el usuario al vector.
	 */
	public void libroAgregado() {
		for(int i=0; i<this.vLibros.length;i++) {
			// Guardará el libro en una posición vacia del vector.
			if(vLibros[i] == null) {
				Libro nuevoLibro = new Libro();
				nuevoLibro.setTitulo(textTitulo.getText());
				nuevoLibro.setAutor(textAutor.getText());
				nuevoLibro.setFecha(textAño.getText());
				vLibros[i] = nuevoLibro;
				JOptionPane.showMessageDialog(null, "Libro guardado temporalmente", "", JOptionPane.INFORMATION_MESSAGE);
				break;
			}
		}
	}
	/**
	 * Método que escribe la información del vector dentro del fichero.
	 * 
	 * @param rutaFichero ubicación del fichero que se está usando.
	 */
	public void escribirLibros(String rutaFichero) {
		File fileLibros = new File(rutaFichero);
		try {
			// Revisa que el fichero exista
			if(!fileLibros.exists())
				fileLibros.createNewFile(); // Si no existe lo creará
			FileOutputStream fos = new FileOutputStream(fileLibros);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			// Escribir
			for(int i=0; i < vLibros.length; i++) {
				oos.writeObject((Libro)vLibros[i]);
			}
			// Cerrar
			oos.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	/**
	 * Método que lee la información del fichero y lo añade al JTable de la ventana principal.
	 * 
	 * @param rutaFichero ubicación del fichero que se está usando.
	 */
	public void leerLibros(String rutaFichero) {
		// Se añaden las columnas a la tabla
		DefaultTableModel model = new DefaultTableModel();
	    model.addColumn("Título");
	    model.addColumn("Autor");
	    model.addColumn("Año");
		try {
			FileInputStream fis = new FileInputStream(new File(rutaFichero));
			ObjectInputStream ois = new ObjectInputStream(fis);
			Libro miLibro;
			while((miLibro = (Libro) ois.readObject()) != null) {
				// Se ingresa la información leída.
				model.addRow(new Object[]{miLibro.getTitulo(), miLibro.getAutor(), miLibro.getFecha()});
			}
			// Cerrar
			ois.close();
			// Añadir al JTable
			tblInformacion.setModel(model);
		}catch (EOFException e) {
			// Esta excepción captura el fin de fichero
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	/**
	 * Método que revisará que el vector no esté lleno. Si no encuantra alguna posición vacía en el vector
	 * notificará que está lleno, de lo contrario lo marcará como vacío.
	 * 
	 * @return boolean que notifica el estado del vector.
	 */
	private boolean vectorLleno() {
		for(int i = 0; i < this.vLibros.length; i++) {
			if(vLibros[i] == null) {
				return false;
			}
		}
		return true;
	}
}