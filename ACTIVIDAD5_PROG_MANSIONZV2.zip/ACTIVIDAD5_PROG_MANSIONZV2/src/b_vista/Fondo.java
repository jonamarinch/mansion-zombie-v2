package b_vista;

import java.awt.Graphics;
import java.awt.Image;

import javax.swing.JComponent;

/**
 * Clase que representa el fondo de la ventana visible del programa
 */
public class Fondo extends JComponent{
	
	/**
	 * Imagen con la que se va a trabajar
	 */
	private Image image;
	
	/**
	 * Constructor por parámetro de la clase Fondo
	 * 
	 * @param imageRecibida Recibe una imagen con la que trabajar
	 */
	public Fondo(Image imageRecibida)
	{
		this.image = imageRecibida;
	}
	
	/**
	 * Método para dibujar la imagen. Se llamará automáticamente cuando se tenga que dibujar un JPanel
	 */
	@Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
    }

}
