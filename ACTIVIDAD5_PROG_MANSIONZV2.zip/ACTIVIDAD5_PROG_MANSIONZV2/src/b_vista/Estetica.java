package b_vista;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Rectangle;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.Border;

public class Estetica {
	
	private static int alturaLTF = 19;
	private static int anchuraTF = alturaLTF*2;
	private static int alturaB = alturaLTF*2;
	private static int anchuraB = alturaLTF*6;
	private static Border borderJ = BorderFactory.createLineBorder(Color.BLUE, 2);
	private static Border borderZ = BorderFactory.createLineBorder(Color.RED, 2);
	
	/**
	 * Getter del borde de los lbl relacionados con el Zombi
	 * 
	 * @return Devuelve el borde estilo Zombi
	 */
	public static Border getBorderZombi()
	{
		return borderZ;
	}
	/**
	 * Método para dar estilo a un botón
	 * 
	 * @param botonRecibido El botón a estilizar
	 * @param pos Posición de arriba a abajo en un conjunto de botones
	 * @param x Posición eje horizontal
	 * @param y Posición eje vertical
	 */
	public static void estilizarBoton(JButton botonRecibido, int pos, int x, int y)
	{
		int incr = 45 * pos;
		botonRecibido.setBounds(x, y+incr, Estetica.anchuraB, Estetica.alturaB);
	}
	/**
	 * Método para estilizar un label
	 * 
	 * @param lblRecibido label recibido
	 * @param pos Posición de arriba a abajo en un conjunto de labels
	 * @param anch Anchura del label según su texto
	 * @param x Posición eje horizontal
	 * @param y Posición eje vertical
	 */
	public static void estilizarLabel(JLabel lblRecibido, int pos, int x, int y)
	{
		lblRecibido.setFont(new Font("Tahoma", Font.PLAIN, 15));
		int incr = 30 * pos;
		lblRecibido.setBounds(x, y+incr, Estetica.getAnchuraLabel(lblRecibido)+10, Estetica.alturaLTF);
		lblRecibido.setForeground(Color.WHITE);
		lblRecibido.setOpaque(true);
		lblRecibido.setBackground(Color.DARK_GRAY);
		lblRecibido.setBorder(Estetica.borderJ);
	}
	/**
	 * Método para estilizar un textField
	 * 
	 * @param tFRecibido textField recibido
	 * @param pos Posición de arriba a abajo en un conjunto de textFields
	 * @param x Posición eje horizontal
	 * @param y Posición eje vertical
	 */
	public static void estilizarTextField(JTextField tFRecibido, int pos, int x, int y)
	{
		tFRecibido.setEditable(false);
		int incr = 30 * pos;
		tFRecibido.setBounds(x, y+incr, Estetica.anchuraTF, Estetica.alturaLTF);
	}
	/**
	 *Método para estilizar un textArea
	 * 
	 * @param tARecibido textArea recibido
	 */
	public static void estilizarTextArea(JTextArea tARecibido)
	{
		tARecibido.setBounds(15, 145, 280, 350);
		tARecibido.setEditable(false);
	}
	/**
	 * Método para obtener la anchura de un label según su texto
	 * 
	 * @param lblRecibido label recibido
	 * @return Devuelve la anchura
	 */
	public static int getAnchuraLabel(JLabel lblRecibido)
	{
		FontMetrics metrics = lblRecibido.getFontMetrics(lblRecibido.getFont());
        Rectangle bounds = metrics.getStringBounds(lblRecibido.getText(), null).getBounds();
        return bounds.width;
	}
}
