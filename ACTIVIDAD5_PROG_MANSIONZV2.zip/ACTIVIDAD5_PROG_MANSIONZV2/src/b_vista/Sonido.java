package b_vista;

import java.io.File;

/**
 * Clase que representa un sonido a reproducir en el programa
 */
public class Sonido {

	/**
	 * Archivo de sonido con el que se va a trabajar
	 */
	private File ficheroSonido;
	
	/**
	 * Constructor por parámetro de la clase Sonido
	 * 
	 * @param sonidoRecibido Recibe un fichero de sonido con el que trabajar
	 */
	public Sonido(File sonidoRecibido)
	{
		this.ficheroSonido = sonidoRecibido;
	}
}
