package visual;

import java.awt.EventQueue;
import java.awt.Image;
import java.io.File;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;

public class Inicio extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Inicio frame = new Inicio();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Inicio() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 750, 550);
		// Carga la imagen de fondo
        Image backgroundImage = new ImageIcon("src"+File.separator+"fondos"+File.separator+"1-fondo-inicio.jpg").getImage();
        // Crea un panel con la imagen de fondo
        ImagenPaneles panel = new ImagenPaneles(backgroundImage);
        // Establece el panel como el panel de contenido del JFrame
        setContentPane(panel);
        // Pon música
        // Musica musica = new Musica();
		
		panel.setBorder(new EmptyBorder(5, 5, 5, 5));
		this.setLocationRelativeTo(null);
		
		panel.setLayout(null);
		
		JButton btnNewButton_1 = new JButton("Jugar");
		btnNewButton_1.setBounds(185, 120, 180, 40);
		panel.add(btnNewButton_1);
		
		JButton btnNewButton = new JButton("Cargar Partida");
		btnNewButton.setBounds(185, 220, 180, 40);
		panel.add(btnNewButton);
		
		JButton btnVerHistrico = new JButton("Ver Histórico");
		btnVerHistrico.setBounds(185, 320, 180, 40);
		panel.add(btnVerHistrico);
		
		String[] dificultades = new String[2];
		dificultades[0] = "FÁCIL";
		dificultades[1] = "DIFÍCIL";
		
		JComboBox comboBox = new JComboBox(dificultades);
		comboBox.setBounds(395, 125, 130, 30);
		panel.add(comboBox);
	}
}
