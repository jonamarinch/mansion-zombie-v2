package visual;

import javax.sound.sampled.*;
import java.io.File;
import java.io.IOException;

public class Musica {
	
	public static void main(String[] args) {
        // Load the sound file
        File soundFile = new File("src"+File.separator+"musica"+File.separator+"spooky.wav");

        try {
            // Get an AudioInputStream
            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(soundFile);

            // Get a Clip resource
            Clip clip = AudioSystem.getClip();

            // Open the audio clip with the AudioInputStream
            clip.open(audioInputStream);

            // Loop the clip indefinitely
            clip.loop(Clip.LOOP_CONTINUOUSLY);

            // Keep the program running until it's terminated
            // System.out.println("Music playing. Press Ctrl+C to exit.");

        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            e.printStackTrace();
        }
    }

}
