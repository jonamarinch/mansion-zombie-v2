package main;

import java.util.Scanner;

import acciones.Println;
import acciones.Menu;
import personajes.Zombi;
import personajes.Superv;
import acciones.Dado;
import acciones.Lucha;
import acciones.Buscar;
import acciones.Botiquin;
import acciones.Avanzar;

public class Juego {
	//Ahora, reorganizar todo
	//En el JuegoBucle. Necesito añadir darle valor a las armas y a las protecciones. Y hacer que el Zombi ataque también. Todo esto es en los combates.
	
	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		Println notificaciones = new Println();
		Menu sn = new Menu();
		Dado dado = new Dado();
		Lucha lucha = new Lucha();
		Buscar buscar = new Buscar();
		Avanzar avanzar = new Avanzar();
		Botiquin botiquin = new Botiquin();
		Fin fin = new Fin();
		
		//Inicio de todo, elección del modo de dificultad:
		JuegoInicio modo = new JuegoInicio();
		modo.JuegoModos(notificaciones, teclado);
		
		//Añadir nombre al superviviente y confirmar su entrada a la mansión:
		Superv superviviente = new Superv();
		superviviente.construirSuperv(notificaciones, teclado, sn, fin);
		
		//Entrar en la Mansión Zombi:
		Habitacion habit = new Habitacion();
		habit.EntradaMansion(notificaciones, teclado, superviviente, modo.GetDifJuego());
		
		//Entrar en una habitación y jugar:
		JuegoBucle bucle = new JuegoBucle(); 
		bucle.Bucle(notificaciones, teclado, habit, superviviente, sn, dado, lucha, botiquin, buscar, avanzar, fin);
		}
	}