package main;

import java.util.Scanner;
import acciones.Println;

public class JuegoInicio {
	
private boolean JuegoFacil;
	
	public void JuegoModos(Println notificaciones, Scanner teclado) {
		
		boolean dificultadEscogida = false;
		
		notificaciones.dificultad();
		
		while (dificultadEscogida == false) {
		try {
			
			String difJuego = teclado.next();
			
				if (difJuego.equals("1")) {
					dificultadEscogida = true;
					JuegoFacil(notificaciones);
					break;
				}
				else if (difJuego.equals("2")) {
					dificultadEscogida = true;
					JuegoDificil(notificaciones);
					break;
				}
				else if (!difJuego.equals("")) {
					dificultadEscogida = false;
					notificaciones.exception();
				}
		}
		
		catch (Exception e){
			notificaciones.exception();
		}
		}
	}
		
	public void JuegoFacil(Println notificaciones) {
		JuegoFacil = true;
		notificaciones.facil();
	}
	
	public void JuegoDificil(Println notificaciones) {
		JuegoFacil = false;
		notificaciones.dificil();
	}
	
	public boolean GetDifJuego() {
		return JuegoFacil;
	}
}