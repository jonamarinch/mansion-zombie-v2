package main;

import java.util.Scanner;

import acciones.Println;

import personajes.Superv;

public class Habitacion{
	
	public void EntradaMansion(Println notificaciones, Scanner teclado, Superv superviviente, boolean DifJuego) {
		JuegoInicio modo = new JuegoInicio();
		
		if (DifJuego == true) {
			numHabs = 5;
			HabitacionActual = 1;
			numBusquedas = 3;
			numZombis = 1;
		} else if (DifJuego == false) {
			numHabs = 10;
			HabitacionActual = 1;
			numBusquedas = 3;
			numZombis = 1;
		}
		
		notificaciones.llegadaMansion(superviviente.getNombre());
		teclado.nextLine();
	}
	
	public int GetHabitacion() {
		return HabitacionActual;
	}
	
	public void SetHabitacion() {
		HabitacionActual++;
	}
	
	public int GetNumHabs() {
		return numHabs;
	}
	
	public int GetNZombies() {
		return numZombis;
	}
	
	public void masNZombis(int suma) {
		numZombis = numZombis + suma;
	}
	
	public void setNZombis(int n) {
		numZombis = n;
	}
	
	public void menosNZombis(int resta) {
		numZombis = numZombis - resta;
	}
	
	public void UsarBusquedas() {
		numBusquedas--;
	}
	
	public int GetBusquedas() {
		return numBusquedas;
	}
	
	private int HabitacionActual;
	private int numHabs;
	private int numBusquedas;
	private int numZombis;
}