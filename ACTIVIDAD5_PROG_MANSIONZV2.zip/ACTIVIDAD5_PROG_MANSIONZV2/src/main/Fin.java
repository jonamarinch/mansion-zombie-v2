package main;

import acciones.Println;

import personajes.Superv;

public class Fin {
	
	public void ejecutarFinVoluntario(Println notificaciones) {
		notificaciones.finVoluntario();
		System.exit(0);
	}
	
	public void ejecutarFinTrasMuerte(Println notificaciones) {
		notificaciones.finTrasMuerte();
		System.exit(0);
	}
	
	public void ejecutarFinTrasVictoria(Println notificaciones, Superv superviviente) {
		notificaciones.finVictoria(superviviente.getNombre());
		System.exit(0);
	}
}