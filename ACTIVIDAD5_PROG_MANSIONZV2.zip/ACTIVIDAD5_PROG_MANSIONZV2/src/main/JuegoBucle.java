package main;

import java.util.Scanner;

import acciones.Println;
import acciones.Menu;
import acciones.Lucha;
import acciones.Dado;
import acciones.Buscar;
import personajes.Superv;
import java.util.ArrayList;
import personajes.Zombi;
import acciones.Avanzar;
import acciones.Botiquin;

public class JuegoBucle {
	
	public void Bucle(Println notificaciones, Scanner teclado, Habitacion habit, Superv superviviente,
			Menu sn, Dado dado, Lucha lucha, Botiquin botiquin, Buscar buscar, Avanzar avanzar, Fin fin) {
		
		// Todo esto se inicia mientras estemos en una habitación dentro de la mansión
		while(habit.GetHabitacion() <= habit.GetNumHabs()) {
			
			notificaciones.status(superviviente.getNombre(), habit.GetHabitacion(),
					habit.GetNumHabs());
					
				// Ahora se hace la lucha entre el superviviente y los zombis
					
				lucha.combate(notificaciones, teclado, superviviente, sn, habit, dado, fin);
				
				// MENÚ
				while (true) {
					// MENÚ 1: Avanzo
					if (superviviente.getBotiquin() != true && habit.GetBusquedas() == 0) {
						notificaciones.primerMenu(superviviente.getNombre(), habit.GetBusquedas());
						int resultadoMenu = sn.unaOpcion(teclado, notificaciones);
						
							if (resultadoMenu == 1) {
								avanzar.sigHabitacion(habit, notificaciones, superviviente);
								break;
							}
							
					}
					// MENÚ 2: Avanzo o busco
					if (superviviente.getBotiquin() != true && habit.GetBusquedas() != 0) {
						notificaciones.segundoMenu(superviviente.getNombre());
						int resultadoMenu = sn.dosOpciones(teclado, notificaciones);
						
							if (resultadoMenu == 1) {
								avanzar.sigHabitacion(habit, notificaciones, superviviente);
								break;
							}
							else if (resultadoMenu == 2) {
								buscar.ejecutarBusqueda(notificaciones, teclado, dado, superviviente, 
										sn, habit, botiquin, fin, lucha);
							}
					}		
					// MENÚ 3: Avanzo o me curo
					if (superviviente.getBotiquin() == true && habit.GetBusquedas() == 0) {
						notificaciones.tercerMenu(superviviente.getNombre());
						int resultadoMenu = sn.dosOpciones(teclado, notificaciones);
						
							if (resultadoMenu == 1) {
								avanzar.sigHabitacion(habit, notificaciones, superviviente);
								break;
							}
							else if (resultadoMenu == 2) {
								botiquin.usarBotiquin(notificaciones, superviviente);
							}
					}
					// MENÚ 4: Avanzo o busco o me curo
					if (superviviente.getBotiquin() == true && habit.GetBusquedas() != 0) {
						notificaciones.cuartoMenu(superviviente.getNombre());
						int resultadoMenu = sn.tresOpciones(teclado, notificaciones);
						
							if (resultadoMenu == 1) {
								avanzar.sigHabitacion(habit, notificaciones, superviviente);
								break;
							}
							else if (resultadoMenu == 2) {
								buscar.ejecutarBusqueda(notificaciones, teclado, dado, superviviente, 
										sn, habit, botiquin, fin, lucha);
							}
							else if (resultadoMenu == 3) {
								botiquin.usarBotiquin(notificaciones, superviviente);
							}
					}
				}
				// Pero sí ya he terminado con la última habitación, es el fin del juego por victoria
				if(habit.GetHabitacion() == habit.GetNumHabs()){
					fin.ejecutarFinTrasVictoria(notificaciones, superviviente);
				}
				
			}
	}
}