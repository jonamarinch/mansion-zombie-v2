package personajes;

import java.util.Scanner;

import acciones.Println;
import acciones.Menu;
import main.Fin;

public class Superv {

String nombre;
int PuntosVida = 20;
int PuntosAtaque = 4;
boolean Botiquin = false;
int ArmasCantidad = 0;
int ProteccionesCantidad = 0;
	
	public void construirSuperv(Println notificaciones, Scanner teclado, Menu sn, Fin fin) {
		notificaciones.eligeNombre();
		nombre = teclado.next();
		
		notificaciones.listoMansion(nombre);
		int listoMansion1 = sn.dosOpciones(teclado, notificaciones);
				
		if (listoMansion1 == 1) {
			notificaciones.viajeMansion();
			}
		else if (listoMansion1 == 2) {
			fin.ejecutarFinVoluntario(notificaciones);
			}
		}

	
	public int getPuntosVida() {
		return PuntosVida;
	}
	
	public void setPuntosVida(int num, int proteccion) {
		PuntosVida = PuntosVida - (num - proteccion);
	}
	
	public int getPuntosAtaque() {
		return PuntosAtaque;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public void ganoBotiquin() {
		Botiquin = true;
	}
	
	public void ganoProteccion() {
		ProteccionesCantidad++;
	}
	
	public int getProteccion() {
		return ProteccionesCantidad;
	}
	
	public void ganoArmas() {
		ArmasCantidad++;
	}
	
	public int getArmas() {
		return ArmasCantidad;
	}
	
	public void usoBotiquin() {
		PuntosVida = PuntosVida + 4;
		if (PuntosVida > 20)
			PuntosVida = 20;
		Botiquin = false;
	}
	
	public boolean getBotiquin() {
		return Botiquin;
	}
}