package personajes;
import main.Habitacion;
import acciones.Dado;
import java.util.Random;

public class Zombi {
	
int PuntosVida;
int PuntosAtaque;
	
	public Zombi(Dado dado, Habitacion mansion) {
		PuntosVida = dado.Dos()+2+(mansion.GetHabitacion()-1);
		PuntosAtaque = dado.Dos()+2+(mansion.GetHabitacion()-1);
	}
	
	public void regenerar(Dado dado, Habitacion mansion) {
		PuntosVida = dado.Dos()+2+(mansion.GetHabitacion()-1);
		PuntosAtaque = dado.Dos()+2+(mansion.GetHabitacion()-1);
	}
	
	public int getPuntosVida() {
		return PuntosVida;
	}
	
	public void setPuntosVida(int num, int armas) {
		PuntosVida = PuntosVida - (num + armas);
	}
	
	public int getPuntosAtaque() {
		return PuntosAtaque;
	}
}