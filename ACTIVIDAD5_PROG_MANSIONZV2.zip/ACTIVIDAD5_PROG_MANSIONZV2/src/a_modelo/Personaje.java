package a_modelo;

/**
 * Clase abstracta que heredarán tanto 'zombi' como 'usuario'
 */
public abstract class Personaje {
	
	/**
	 * Puntos de vida del personaje
	 */
	private int puntosVida;
	/**
	 * Puntos de ataque del personaje
	 */
	private int puntosAtaque;
	
	/**
	 * Getter de los puntos de vida
	 * 
	 * @return Devuelve los puntos de vida
	 */
	public int getPuntosVida() {
		return puntosVida;
	}
	
	/**
	 * Setter de los puntos de vida
	 * 
	 * @param puntosVida Recibe los puntos de vida a establecer
	 */
	public void setPuntosVida(int puntosVida) {
		this.puntosVida = puntosVida;
	}
	
	/**
	 * Getter de los puntos de ataque
	 * 
	 * @return Devuelve los puntos de ataque
	 */
	public int getPuntosAtaque() {
		return puntosAtaque;
	}
	
	/**
	 * Setter de los puntos de ataque
	 * 
	 * @param puntosVida Recibe los puntos de ataque a establecer
	 */
	public void setPuntosAtaque(int puntosAtaque) {
		this.puntosAtaque = puntosAtaque;
	}
	
	/**
	 * Método para añadir puntos de vida a la vida
	 * 
	 * @param PV Se recibe un número de puntos de vida a sumar
	 */
	public void annadirPuntosVida(int PV)
	{
		this.setPuntosVida(this.getPuntosVida()+PV);
	}
	
	/**
	 * Método para restar puntos de vida a la vida
	 * 
	 * @param PV Se recibe un número de puntos de vida a restar
	 */
	public void restarPuntosVida(int PV)
	{
		this.setPuntosVida(this.getPuntosVida()-PV);
	}
	
	/**
	 * Método para atacar
	 * 
	 * @return Devuelve un int elegido al azar según los puntos de ataque
	 */
	public int atacar()
	{
		Dado dado = new Dado();
		return dado.randomLanzarAtaque(this.puntosAtaque);
	}

}
