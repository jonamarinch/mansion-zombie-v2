package a_modelo;

import java.util.Random;

/**
 * Clase que representa la funcionalidad de devolver un resultado aleatorio
 */
public class Dado {
	
	/**
	 * Objeto random usado para obtener datos aleatorios
	 */
	private Random rnd;
	
	/**
	 * Método constructor por defecto
	 */
	public Dado()
	{
		this.rnd = new Random();
	}
	
	/**
	 * Método para devolver puntos de vida o de ataque del Zombi. Se obtendrán aleatoriamente dentro de un rango.
	 * 
	 * @param habitacionActual Se debe pasar la habitación de la Mansión en la que se encuentre el usuario
	 * @return Devuelve la cifra obtenida
	 */
	public int randomPuntosZombi(int habitacionActual)
	{
		int puntosZombi = rnd.nextInt(2)+2+(habitacionActual-1);
		return puntosZombi;
	}
	
	/**
	 * Método para devolver un ataque a partir de los puntos de ataque de un personaje
	 * 
	 * @param puntosAtaque Son los puntos de ataque del personaje
	 * @return Devuelve el ataque resultante
	 */
	public int randomLanzarAtaque(int puntosAtaque)
	{
		int resultadoAtaque = rnd.nextInt(puntosAtaque);
		return resultadoAtaque;
	}
	
	/**
	 * Método para obtener un número aleatorio de 100. Se utiliza en las búsquedas del superviviente en una habitación
	 * 
	 * @return Devuelve la cifra obtenida
	 */
	public int lanzarDado100()
	{
		int resultadoDado100 = rnd.nextInt(100);
		return resultadoDado100;
	}
}
