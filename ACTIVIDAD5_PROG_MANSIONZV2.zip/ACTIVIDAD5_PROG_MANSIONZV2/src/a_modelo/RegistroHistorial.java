package a_modelo;

/**
 * Clase para registrar el resultado de una partida finalizada
 */
public class RegistroHistorial {
	
	/**
	 * @param resultado
	 * @param dificultad
	 * @param habitacion
	 * @param restantesPV
	 * @param isTeniaBotiquin
	 * @param numArmas
	 * @param numProtecc
	 */
	public RegistroHistorial(Resultado resultado, Dificultad dificultad, int habitacion, int restantesPV,
			boolean isTeniaBotiquin, int numArmas, int numProtecc) {
		super();
		this.resultado = resultado;
		this.dificultad = dificultad;
		this.habitacion = habitacion;
		this.restantesPV = restantesPV;
		this.isTeniaBotiquin = isTeniaBotiquin;
		this.numArmas = numArmas;
		this.numProtecc = numProtecc;
	}
	/**
	 * Resultado de la partida
	 */
	private Resultado resultado;
	/**
	 * Dificultad de la partida
	 */
	private Dificultad dificultad;
	/**
	 * Posicion de la habitacion
	 */
	private int habitacion;
	/**
	 * Puntos de vida restantes al terminar la partida
	 */
	private int restantesPV;
	/**
	 * Booleano true si tenía botiquín
	 */
	private boolean isTeniaBotiquin;
	/**
	 * Número de armas
	 */
	private int numArmas;
	/**
	 * Número de protecciones
	 */
	private int numProtecc;
	/**
	 * @return the resultado
	 */
	public Resultado getResultado() {
		return resultado;
	}
	/**
	 * @param resultado the resultado to set
	 */
	public void setResultado(Resultado resultado) {
		this.resultado = resultado;
	}
	/**
	 * @return the dificultad
	 */
	public Dificultad getDificultad() {
		return dificultad;
	}
	/**
	 * @param dificultad the dificultad to set
	 */
	public void setDificultad(Dificultad dificultad) {
		this.dificultad = dificultad;
	}
	/**
	 * @return the habitacion
	 */
	public int getHabitacion() {
		return habitacion;
	}
	/**
	 * @param habitacion the habitacion to set
	 */
	public void setHabitacion(int habitacion) {
		this.habitacion = habitacion;
	}
	/**
	 * @return the restantesPV
	 */
	public int getRestantesPV() {
		return restantesPV;
	}
	/**
	 * @param restantesPV the restantesPV to set
	 */
	public void setRestantesPV(int restantesPV) {
		this.restantesPV = restantesPV;
	}
	/**
	 * @return the isTeniaBotiquin
	 */
	public boolean isTeniaBotiquin() {
		return isTeniaBotiquin;
	}
	/**
	 * @param isTeniaBotiquin the isTeniaBotiquin to set
	 */
	public void setTeniaBotiquin(boolean isTeniaBotiquin) {
		this.isTeniaBotiquin = isTeniaBotiquin;
	}
	/**
	 * @return the numArmas
	 */
	public int getNumArmas() {
		return numArmas;
	}
	/**
	 * @param numArmas the numArmas to set
	 */
	public void setNumArmas(int numArmas) {
		this.numArmas = numArmas;
	}
	/**
	 * @return the numProtecc
	 */
	public int getNumProtecc() {
		return numProtecc;
	}
	/**
	 * @param numProtecc the numProtecc to set
	 */
	public void setNumProtecc(int numProtecc) {
		this.numProtecc = numProtecc;
	}
}
