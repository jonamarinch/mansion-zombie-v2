package a_modelo;

/**
 * Clase en la que se guardan los filtros para el historial
 */
public enum Resultado {
	CUALQUIERA, DERROTA, VICTORIA;
}
