package a_modelo;

/**
 * Clase que representa al Zombi enemigo contra el que luchar
 */
public class Zombi extends Personaje{
	
	/**
	 * Constructor parametrizado de la clase Zombi
	 * 
	 * @param puntosVida Recibe los puntos de vida a establecer en el nuevo Zombi 
	 * @param puntosAtaque Recibe los puntos de ataque a establecer en el nuevo Zombi
	 */
	public Zombi(int puntosVida, int puntosAtaque)
	{
		this.setPuntosVida(puntosVida);
		this.setPuntosAtaque(puntosAtaque);
	}

}
