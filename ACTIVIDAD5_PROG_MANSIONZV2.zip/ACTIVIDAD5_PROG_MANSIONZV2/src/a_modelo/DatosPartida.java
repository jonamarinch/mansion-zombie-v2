package a_modelo;

/**
 * Clase en la que almacenar todos los datos de una partida
 */
public class DatosPartida {
	
	/**
	 * El superviviente o usuario (estático)
	 */
	private static Superviviente superv;
	/**
	 * El superviviente o usuario (no estático)
	 */
	private Superviviente s;
	/**
	 * Zombi que haya en la habitación (estático)
	 */
	private static Zombi zombi;
	/**
	 * Zombis que haya en la habitación (no estático)
	 */
	private Zombi z;
	/**
	 * Número total de zombis en la habitación (estático)
	 */
	private static int numTotalZombis;
	/**
	 * Número total de zombis en la habitación (no estático)
	 */
	private int nTZ;
	/**
	 * Número total de habitaciones (estático)
	 */
	private static int numTotalHabitaciones;
	/**
	 * Número total de habitaciones (no estático)
	 */
	private int nTH;
	/**
	 * Posición actual en las habitaciones (estático)
	 */
	private static int posActualHabitaciones;
	/**
	 * Posición actual en las habitaciones (no estático)
	 */
	private int pAH;
	/**
	 * Número de intentos de búsqueda en la habitación (estático)
	 */
	private static int numIntentosBusqueda;
	/**
	 * Número de intentos de búsqueda en la habitación (no estático)
	 */
	private int nIB;
	
	/**
	 * Constructor parametrizado (crearé objetos para almacenar los datos en ficheros binarios)
	 */
	public DatosPartida(Superviviente s, Zombi z, int nTZ, int nTH, int pAH)
	{
		this.s = s;
		this.z = z;
		this.nTZ = nTZ;
		this.nTH = nTH;
		this.pAH = pAH;
	}
	
	/*
	 * Getters no estáticos
	 */
	/**
	 * @return Devuelve el superviviente (no estático)
	 */
	public Superviviente getS()
	{
		return this.s;
	}
	/**
	 * @return Devuelve el zombi (no estático)
	 */
	public Zombi getZ()
	{
		return this.z;
	}
	/**
	 * @return Devuelve el número total de zombis (no estático)
	 */
	public int getNTZ()
	{
		return this.nTZ;
	}
	/**
	 * @return Devuelve el número total de habitaciones (no estático)
	 */
	public int getNTH()
	{
		return this.nTH;
	}
	/**
	 * @return Devuelve la posición actual en las habitaciones (no estático)
	 */
	public int getPAH()
	{
		return this.pAH;
	}
	/**
	 * @return Devuelve el número de intentos de búsqueda que quedan en la habitación
	 */
	public int getNIB()
	{
		return this.nIB;
	}
	/*
	 * Getters y Setters estáticos
	 */
	/**
	 * @return the superv
	 */
	public static Superviviente getSuperv() {
		return superv;
	}
	/**
	 * @param superv the superv to set
	 */
	public static void setSuperv(Superviviente superv) {
		DatosPartida.superv = superv;
	}
	/**
	 * @return the zombi
<	 */
	public static Zombi getZombi() {
		return zombi;
	}
	/**
	 * @param zombi the zombi to set
	 */
	public static void setZombi(Zombi zombi) {
		DatosPartida.zombi = zombi;
	}
	/**
	 * @return the numTotalZombis
	 */
	public static int getNumTotalZombis()
	{
		return numTotalZombis;
	}
	/**
	 * @param numTotalZombis the numTotalZombis to set
	 */
	public static void setNumTotalZombis(int numTotalZombis)
	{
		DatosPartida.numTotalZombis = numTotalZombis;
	}
	/**
	 * Método para restar 1 al número total de Zombis (tras matar un Zombi)
	 */
	public static void restarNumTotalZombis()
	{
		DatosPartida.numTotalZombis--;
	}
	/**
	 * @return the numTotalHabitaciones
	 */
	public static int getNumTotalHabitaciones() {
		return numTotalHabitaciones;
	}
	/**
	 * @param numTotalHabitaciones the numTotalHabitaciones to set
	 */
	public static void setNumTotalHabitaciones(int numTotalHabitaciones) {
		DatosPartida.numTotalHabitaciones = numTotalHabitaciones;
	}
	/**
	 * @return the posActualHabitaciones
	 */
	public static int getPosActualHabitaciones() {
		return posActualHabitaciones;
	}
	/**
	 * @param posActualHabitaciones the posActualHabitaciones to set
	 */
	public static void setPosActualHabitaciones(int posActualHabitaciones) {
		DatosPartida.posActualHabitaciones = posActualHabitaciones;
	}
	/**
	 * Método para añadir una posición actual dentro de las habitaciones
	 */
	public static void annadirPosActual()
	{
		DatosPartida.posActualHabitaciones++;
	}
	/**
	 * @return the numIntentosBusqueda
	 */
	public static int getNumIntentosBusqueda()
	{
		return numIntentosBusqueda;
	}
	/**
	 * @param numIntentosBusqueda the numIntentosBusqueda to set
	 */
	public static void setNumIntentosBusqueda(int numIntentosBusqueda)
	{
		DatosPartida.numIntentosBusqueda = numIntentosBusqueda;
	}
	/**
	 * Restar un intento de búsqueda
	 */
	public static void restarIntentoBusqueda()
	{
		DatosPartida.numIntentosBusqueda = DatosPartida.numIntentosBusqueda-1;
	}
}
