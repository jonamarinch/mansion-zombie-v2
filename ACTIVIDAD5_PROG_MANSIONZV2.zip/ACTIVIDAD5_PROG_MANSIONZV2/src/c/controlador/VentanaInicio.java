package c.controlador;

import java.awt.EventQueue;
import java.awt.Image;
import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import b.vista.Fondo;

/**
 * Clase que representa la ventana de inicio desde la que se inicia el programa
 */
public class VentanaInicio extends JFrame {

	/**
	 * Número de versión de serialización
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * Panel de la ventana
	 */
	private JPanel contentPane;

	/**
	 * Método para iniciar el programa MANSIÓN ZOMBI V2
	 * 
	 * @param args Argumentos de la línea de comandos (no utilizado en este ejemplo)
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaInicio frame = new VentanaInicio();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Método para crear el frame
	 */
	public VentanaInicio() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 750, 550);
		// Guarda la imagen de fondo
        Image backgroundImage = new ImageIcon("src"+File.separator+"z.fondos"+File.separator+"1-fondo-inicio.jpg").getImage();
        // Crea un panel con la imagen de fondo
        Fondo panelFondo = new Fondo(backgroundImage);
        // Establece el panel como el panel de contenido del JFrame
        setContentPane(panelFondo);
        /*
        // Pon música
        // Musica musica = new Musica();
         */
		
        panelFondo.setBorder(new EmptyBorder(5, 5, 5, 5));
		this.setLocationRelativeTo(null);
		
		panelFondo.setLayout(null);
		
		JButton button_jugar = new JButton("Jugar");
		button_jugar.setBounds(185, 120, 180, 40);
		panelFondo.add(button_jugar);
//		button_jugar.addActionListener(null);
		
		JButton button_cargar = new JButton("Cargar Partida");
		button_cargar.setBounds(185, 220, 180, 40);
		panelFondo.add(button_cargar);
		
		JButton button_historial = new JButton("Ver Histórico");
		button_historial.setBounds(185, 320, 180, 40);
		panelFondo.add(button_historial);
		
		String[] dificultades = new String[3];
		dificultades[0] = "FÁCIL";
		dificultades[1] = "MEDIO";
		dificultades[2] = "DIFÍCIL";
		
		JComboBox comboBox = new JComboBox(dificultades);
		comboBox.setBounds(395, 125, 130, 30);
		panelFondo.add(comboBox);
	}

}
