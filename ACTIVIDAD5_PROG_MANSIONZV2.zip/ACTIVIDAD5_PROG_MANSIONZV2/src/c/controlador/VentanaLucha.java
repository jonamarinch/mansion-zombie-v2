package c.controlador;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.*;

import b.vista.Fondo;
import b.vista.Medidas;

public class VentanaLucha extends JDialog {
	
	/**
	 * TextArea en el que mostrar al usuario lo que ocurre en el programa
	 */
	private static JTextArea textArea;
	/**
	 * Botón para luchar con el zombi
	 */
	private static JButton botonLuchar;
	/**
	 * Botón para continuar
	 */
	private static JButton botonContinuar;
	/**
	 * TextField para los puntos de vida del jugador
	 */
	private JTextField jTFJugPV;
	private JTextField jTFJugPA;
	private JTextField jTFZomPV;
	private JTextField jTFZomPA;

	/**
	 * Lanzar la aplicación
	 */
	public static void main(String[] args) {
		try {
			JFrame propietario = new JFrame();
			propietario.setResizable(false);
			VentanaLucha dialog = new VentanaLucha(propietario, "Prueba");
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Crear el diálogo
	 */
	public VentanaLucha(JFrame propietario, String tituloDifSelecc) {
		/*
		 * Configuraciones básicas del JDialog
		 */
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 750, 550);
        Image backgroundImage = new ImageIcon("src"+File.separator+"z.fondos"+File.separator+"3-fondo-lucha-b.jpg").getImage(); // Guarda la imagen de fondo
        Fondo panelFondo = new Fondo(backgroundImage); // Crea un panel con la imagen de fondo
        setContentPane(panelFondo); // Establece el panel como el panel de contenido del JFrame
        panelFondo.setBorder(new EmptyBorder(5, 5, 5, 5));
		this.setLocationRelativeTo(null);
		panelFondo.setLayout(null);
		this.setTitle(tituloDifSelecc);
		
		/*
		 * Elementos del JDialog
		 */
		textArea = new JTextArea();
		textArea.setBounds(15, 145, 280, 350);
		textArea.setEditable(false);
		JScrollPane scrollPane = new JScrollPane(textArea); // Se mete en un JScrollPane para que se pueda hacer scroll
		scrollPane.setBounds(textArea.getBounds());
		panelFondo.add(scrollPane);
		
		botonLuchar = new JButton("Luchar");
		estilizarBoton(botonLuchar, 0);
		panelFondo.add(botonLuchar);
		
		botonContinuar = new JButton("Continuar");
		estilizarBoton(botonContinuar, 1);
		botonContinuar.setEnabled(false);
		panelFondo.add(botonContinuar);
		
		JLabel lblJugPV = new JLabel("Jugador PV:");
		estilizarLabel(lblJugPV, 0, 88);
		Border borderJ = BorderFactory.createLineBorder(Color.BLUE, 2);
		lblJugPV.setBorder(borderJ);
		panelFondo.add(lblJugPV);
		
		JLabel lblJugPA = new JLabel("Jugador ATK:");
		estilizarLabel(lblJugPA, 1, 97);
		lblJugPA.setBorder(borderJ);
		panelFondo.add(lblJugPA);
		
		JLabel lblZomPV = new JLabel("Zombi PV:");
		estilizarLabel(lblZomPV, 2, 75);
		Border borderZ = BorderFactory.createLineBorder(Color.RED, 2);
		lblZomPV.setBorder(borderZ);
		panelFondo.add(lblZomPV);
		
		JLabel lblZomPA = new JLabel("Zombi ATK:");
		estilizarLabel(lblZomPA, 3, 85);
		lblZomPA.setBorder(borderZ);
		panelFondo.add(lblZomPA);
		
		jTFJugPV = new JTextField();
		estilizarTextField(jTFJugPV, 0);
		panelFondo.add(jTFJugPV);
		
		jTFJugPA = new JTextField();
		estilizarTextField(jTFJugPA, 1);
		panelFondo.add(jTFJugPA);
		
		jTFZomPV = new JTextField();
		estilizarTextField(jTFZomPV, 2);
		panelFondo.add(jTFZomPV);
		
		jTFZomPA = new JTextField();
		estilizarTextField(jTFZomPA, 3);
		panelFondo.add(jTFZomPA);
		
		/*
		 * Al cerrar la ventana, se reactivan los botones del inicio
		 */
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {
            	try {
            		VentanaHabitacion.activarBotones();
            	} catch (Exception ex){
            	}
            }
        });
	}
	
	private void estilizarBoton(JButton botonRecibido, int pos)
	{
		int incr = 45 * pos;
		botonRecibido.setBounds(310, 285+incr, Medidas.anchuraB, Medidas.alturaB);
	}
	
	private void estilizarLabel(JLabel lblRecibido, int pos, int anch)
	{
		lblRecibido.setFont(new Font("Tahoma", Font.PLAIN, 15));
		int incr = 30 * pos;
		lblRecibido.setBounds(15, 22+incr, anch, Medidas.alturaLTF);
		lblRecibido.setForeground(Color.WHITE);
		lblRecibido.setOpaque(true);
		lblRecibido.setBackground(Color.DARK_GRAY);
	}
	
	private void estilizarTextField(JTextField tFRecibido, int pos)
	{
		tFRecibido.setEditable(false);
		int incr = 30 * pos;
		tFRecibido.setBounds(135, 22+incr, Medidas.anchuraTF, Medidas.alturaLTF);
	}

}
