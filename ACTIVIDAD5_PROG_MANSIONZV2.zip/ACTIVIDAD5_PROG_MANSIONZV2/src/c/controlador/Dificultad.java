package c.controlador;

/**
 * Clase en la que se guardan las opciones de dificultad como datos de tipo numerado
 */
public enum Dificultad {
	
	FÁCIL, MEDIO, DIFÍCIL;

}
