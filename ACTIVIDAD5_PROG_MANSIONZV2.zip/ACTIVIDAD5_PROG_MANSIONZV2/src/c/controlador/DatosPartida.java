package c.controlador;

/**
 * Clase en la que almacenar todos los datos de una partida
 */
public class DatosPartida {

}
