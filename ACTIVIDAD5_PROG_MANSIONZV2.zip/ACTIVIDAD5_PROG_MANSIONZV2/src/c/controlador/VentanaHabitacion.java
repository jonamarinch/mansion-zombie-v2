package c.controlador;

import java.awt.*;
import java.awt.event.*;
import java.io.File;
import javax.swing.*;
import javax.swing.border.*;
import b.vista.Fondo;
import java.awt.*;

/**
 * Clase que representa la ventana desde la que el jugador va a controlar sus acciones en una habitación de la mansión
 */
public class VentanaHabitacion extends JDialog {

	/**
	 * Método para pruebas de la clase VentanaHabitacion
	 */
	public static void main(String[] args) {
		try {
			JFrame propietario = new JFrame();
			VentanaHabitacion dialog = new VentanaHabitacion(propietario, "Prueba", Dificultad.FÁCIL, null);
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Método para crear el Dialog
	 */
	public VentanaHabitacion(JFrame propietario, String tituloDifSelecc, Dificultad difSelecc, DatosPartida datos) {
		/*
		 * Configuraciones básicas del JDialog
		 */
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 750, 550);
        Image backgroundImage = new ImageIcon("src"+File.separator+"z.fondos"+File.separator+"2-fondo-habitacion.jpg").getImage(); // Guarda la imagen de fondo
        Fondo panelFondo = new Fondo(backgroundImage); // Crea un panel con la imagen de fondo
        setContentPane(panelFondo); // Establece el panel como el panel de contenido del JFrame
        panelFondo.setBorder(new EmptyBorder(5, 5, 5, 5));
		this.setLocationRelativeTo(null);
		panelFondo.setLayout(null);
		
		/*
		 * Elementos del JDialog
		 */
		JLabel lblPuntosV = new JLabel("Puntos de Vida:");
		lblPuntosV.setFont(new Font("Tahoma", Font.PLAIN, 15));
		FontMetrics fmetrics = lblPuntosV.getFontMetrics(lblPuntosV.getFont());
		int widthPV = 103;
		int height = fmetrics.getHeight();
		lblPuntosV.setBounds(30, 30, widthPV, height);
		lblPuntosV.setForeground(Color.WHITE);
		lblPuntosV.setOpaque(true);
		lblPuntosV.setBackground(Color.DARK_GRAY);
		panelFondo.add(lblPuntosV);
		
		JTextField jTFPuntosV = new JTextField();
		jTFPuntosV.setEditable(false);
		jTFPuntosV.setBounds(195, 30, height*2, height);
		panelFondo.add(jTFPuntosV);
		
		JLabel lblCantProtecc = new JLabel("Cantidad Protecciones:");
		lblCantProtecc.setFont(new Font("Tahoma", Font.PLAIN, 15));
		int widthCP = 148;
		lblCantProtecc.setBounds(30, 60, widthCP, height);
		lblCantProtecc.setForeground(Color.WHITE);
		lblCantProtecc.setOpaque(true);
		lblCantProtecc.setBackground(Color.DARK_GRAY);
		panelFondo.add(lblCantProtecc);
		
		JTextField jTFCantProtecc = new JTextField();
		jTFCantProtecc.setEditable(false);
		jTFCantProtecc.setBounds(195, 60, height*2, height);
		panelFondo.add(jTFCantProtecc);
		
		JLabel lblCantArmas = new JLabel("Cantidad Armas:");
		lblCantArmas.setFont(new Font("Tahoma", Font.PLAIN, 15));
		int widthCA = 109;
		lblCantArmas.setBounds(30, 90, widthCA, height);
		lblCantArmas.setForeground(Color.WHITE);
		lblCantArmas.setOpaque(true);
		lblCantArmas.setBackground(Color.DARK_GRAY);
		panelFondo.add(lblCantArmas);
		
		JTextField jTFCantArmas = new JTextField();
		jTFCantArmas.setEditable(false);
		jTFCantArmas.setBounds(195, 90, height*2, height);
		panelFondo.add(jTFCantArmas);
		
		JLabel lblBotiquin = new JLabel("¿Botiquín?:");
		lblBotiquin.setFont(new Font("Tahoma", Font.PLAIN, 15));
		int widthB = 70;
		lblBotiquin.setBounds(30, 120, widthB, height);
		lblBotiquin.setForeground(Color.WHITE);
		lblBotiquin.setOpaque(true);
		lblBotiquin.setBackground(Color.DARK_GRAY);
		panelFondo.add(lblBotiquin);
		
		JTextField jTFBotiquin = new JTextField();
		jTFBotiquin.setEditable(false);
		jTFBotiquin.setBounds(195, 120, height*2, height);
		panelFondo.add(jTFBotiquin);
		
		JLabel lblIntentos = new JLabel("Intentos:");
		lblIntentos.setFont(new Font("Tahoma", Font.PLAIN, 15));
		int widthI = 62;
		lblIntentos.setBounds(30, 150, widthI, height);
		lblIntentos.setForeground(Color.WHITE);
		lblIntentos.setOpaque(true);
		lblIntentos.setBackground(Color.DARK_GRAY);
		panelFondo.add(lblIntentos);
		
		JTextField jTFIntentos = new JTextField();
		jTFIntentos.setEditable(false);
		jTFIntentos.setBounds(195, 150, height*2, height);
		panelFondo.add(jTFIntentos);
		
			int nHabs = 0;
			if (difSelecc == Dificultad.FÁCIL){nHabs = 5;} 
			else if (difSelecc == Dificultad.MEDIO){nHabs = 7;} 
			else if (difSelecc == Dificultad.DIFÍCIL){nHabs = 10;}
		JLabel lblHabitacion = new JLabel("Habitación (MAX "+nHabs+"):");
		lblHabitacion.setFont(new Font("Tahoma", Font.PLAIN, 15));
		int widthHab = 134;
		lblHabitacion.setBounds(30, 180, widthHab, height);
		lblHabitacion.setForeground(Color.WHITE);
		lblHabitacion.setOpaque(true);
		lblHabitacion.setBackground(Color.DARK_GRAY);
		panelFondo.add(lblHabitacion);
		
		JTextField jTFHabitacion = new JTextField();
		jTFHabitacion.setEditable(false);
		jTFHabitacion.setBounds(195, 180, height*2, height);
		panelFondo.add(jTFHabitacion);
		
		JLabel lblNZombis = new JLabel("Zombis:");
		lblNZombis.setFont(new Font("Tahoma", Font.PLAIN, 15));
		int widthNZombis = 53;
		lblNZombis.setBounds(30, 210, widthNZombis, height);
		lblNZombis.setForeground(Color.WHITE);
		lblNZombis.setOpaque(true);
		lblNZombis.setBackground(Color.DARK_GRAY);
		panelFondo.add(lblNZombis);
		
		JTextField jTFNZombis = new JTextField();
		jTFNZombis.setEditable(false);
		jTFNZombis.setBounds(195, 210, height*2, height);
		panelFondo.add(jTFNZombis);
		
		JButton jBtnLuchar = new JButton("Luchar");
		jBtnLuchar.setBounds(575, 255, height*6, height*2);
		panelFondo.add(jBtnLuchar);
		
		JButton jBtnCurarse = new JButton("Curarse");
		jBtnCurarse.setBounds(575, 300, height*6, height*2);
		panelFondo.add(jBtnCurarse);
		
		JButton jBtnBuscar = new JButton("Buscar");
		jBtnBuscar.setBounds(575, 345, height*6, height*2);
		panelFondo.add(jBtnBuscar);
		
		JButton jBtnAvanzar = new JButton("Avanzar");
		jBtnAvanzar.setBounds(575, 390, height*6, height*2);
		panelFondo.add(jBtnAvanzar);
		
		JButton jBtnGuardar = new JButton("Guardar");
		jBtnGuardar.setBounds(575, 445, height*6, height*2);
		panelFondo.add(jBtnGuardar);
		
		/*
		 * Al cerrar la ventana, se reactivan los botones del inicio
		 */
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {
            	try {
            		VentanaInicio.activarBotones();
            	} catch (Exception ex){
            	}
            }
        });
	}

}
