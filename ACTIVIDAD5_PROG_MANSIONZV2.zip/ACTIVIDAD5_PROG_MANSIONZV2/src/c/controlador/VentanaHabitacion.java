package c.controlador;

import java.awt.*;
import java.awt.event.*;
import java.io.File;
import javax.swing.*;
import javax.swing.border.*;
import b.vista.Fondo;
import b.vista.Medidas;

import java.awt.*;

/**
 * Clase que representa la ventana desde la que el jugador va a controlar sus acciones en una habitación de la mansión
 */
public class VentanaHabitacion extends JDialog implements ActionListener{
	
	/**
	 * TextField de los puntos de vida
	 */
	private JTextField jTFPuntosV;
	/**
	 * TextField de la cantidad de protecciones
	 */
	private JTextField jTFCantProtecc;
	/**
	 * TextField de la cantidad de armas
	 */
	private JTextField jTFCantArmas;
	/**
	 * TextField del botiquín
	 */
	private JTextField jTFBotiquin;
	/**
	 * TextField del número de intentos de búsqueda
	 */
	private JTextField jTFIntentos;
	/**
	 * TextField del número de habitación
	 */
	private JTextField jTFHabitacion;
	/**
	 * TextField del número de zombis en la habitación
	 */
	private JTextField jTFNZombis;
	/**
	 * Botón para luchar
	 */
	private static JButton jBtnLuchar;
	/**
	 * Botón para curarse
	 */
	private static JButton jBtnCurarse;
	/**
	 * Botón para buscar
	 */
	private static JButton jBtnBuscar;
	/**
	 * Botón para avanzar
	 */
	private static JButton jBtnAvanzar;
	/**
	 * Botón para guardar partida
	 */
	private static JButton jBtnGuardar;
	/**
	 * Ventana para la lucha con un zombi
	 */
	private VentanaLucha ventLucha;

	/**
	 * Método para pruebas de la clase VentanaHabitacion
	 */
	public static void main(String[] args) {
		try {
			JFrame propietario = new JFrame();
			VentanaHabitacion dialog = new VentanaHabitacion(propietario, "Prueba", Dificultad.FÁCIL, null);
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Método para crear el Dialog
	 */
	public VentanaHabitacion(JFrame propietario, String tituloDifSelecc, Dificultad difSelecc, DatosPartida datos) {
		/*
		 * Configuraciones básicas del JDialog
		 */
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 750, 550);
        Image backgroundImage = new ImageIcon("src"+File.separator+"z.fondos"+File.separator+"2-fondo-habitacion.jpg").getImage(); // Guarda la imagen de fondo
        Fondo panelFondo = new Fondo(backgroundImage); // Crea un panel con la imagen de fondo
        setContentPane(panelFondo); // Establece el panel como el panel de contenido del JFrame
        panelFondo.setBorder(new EmptyBorder(5, 5, 5, 5));
		this.setLocationRelativeTo(null);
		panelFondo.setLayout(null);
		this.setTitle(tituloDifSelecc);
		
		/*
		 * Elementos del JDialog
		 */
		JLabel lblPuntosV = new JLabel("Puntos de Vida:");
		lblPuntosV.setFont(new Font("Tahoma", Font.PLAIN, 15));
		int widthPV = 103;
		lblPuntosV.setBounds(30, 30, widthPV, Medidas.alturaLTF);
		lblPuntosV.setForeground(Color.WHITE);
		lblPuntosV.setOpaque(true);
		lblPuntosV.setBackground(Color.DARK_GRAY);
		panelFondo.add(lblPuntosV);
		
		jTFPuntosV = new JTextField();
		jTFPuntosV.setEditable(false);
		jTFPuntosV.setBounds(195, 30, Medidas.anchuraTF, Medidas.alturaLTF);
		panelFondo.add(jTFPuntosV);
		
		JLabel lblCantProtecc = new JLabel("Cantidad Protecciones:");
		lblCantProtecc.setFont(new Font("Tahoma", Font.PLAIN, 15));
		int widthCP = 148;
		lblCantProtecc.setBounds(30, 60, widthCP, Medidas.alturaLTF);
		lblCantProtecc.setForeground(Color.WHITE);
		lblCantProtecc.setOpaque(true);
		lblCantProtecc.setBackground(Color.DARK_GRAY);
		panelFondo.add(lblCantProtecc);
		
		jTFCantProtecc = new JTextField();
		jTFCantProtecc.setEditable(false);
		jTFCantProtecc.setBounds(195, 60, Medidas.anchuraTF, Medidas.alturaLTF);
		panelFondo.add(jTFCantProtecc);
		
		JLabel lblCantArmas = new JLabel("Cantidad Armas:");
		lblCantArmas.setFont(new Font("Tahoma", Font.PLAIN, 15));
		int widthCA = 109;
		lblCantArmas.setBounds(30, 90, widthCA, Medidas.alturaLTF);
		lblCantArmas.setForeground(Color.WHITE);
		lblCantArmas.setOpaque(true);
		lblCantArmas.setBackground(Color.DARK_GRAY);
		panelFondo.add(lblCantArmas);
		
		jTFCantArmas = new JTextField();
		jTFCantArmas.setEditable(false);
		jTFCantArmas.setBounds(195, 90, Medidas.anchuraTF, Medidas.alturaLTF);
		panelFondo.add(jTFCantArmas);
		
		JLabel lblBotiquin = new JLabel("¿Botiquín?:");
		lblBotiquin.setFont(new Font("Tahoma", Font.PLAIN, 15));
		int widthB = 70;
		lblBotiquin.setBounds(30, 120, widthB, Medidas.alturaLTF);
		lblBotiquin.setForeground(Color.WHITE);
		lblBotiquin.setOpaque(true);
		lblBotiquin.setBackground(Color.DARK_GRAY);
		panelFondo.add(lblBotiquin);
		
		jTFBotiquin = new JTextField();
		jTFBotiquin.setEditable(false);
		jTFBotiquin.setBounds(195, 120, Medidas.anchuraTF, Medidas.alturaLTF);
		panelFondo.add(jTFBotiquin);
		
		JLabel lblIntentos = new JLabel("Intentos:");
		lblIntentos.setFont(new Font("Tahoma", Font.PLAIN, 15));
		int widthI = 62;
		lblIntentos.setBounds(30, 150, widthI, Medidas.alturaLTF);
		lblIntentos.setForeground(Color.WHITE);
		lblIntentos.setOpaque(true);
		lblIntentos.setBackground(Color.DARK_GRAY);
		panelFondo.add(lblIntentos);
		
		jTFIntentos = new JTextField();
		jTFIntentos.setEditable(false);
		jTFIntentos.setBounds(195, 150, Medidas.anchuraTF, Medidas.alturaLTF);
		panelFondo.add(jTFIntentos);
		
			int nHabs = 0;
			if (difSelecc == Dificultad.FÁCIL){nHabs = 5;} 
			else if (difSelecc == Dificultad.MEDIO){nHabs = 7;} 
			else if (difSelecc == Dificultad.DIFÍCIL){nHabs = 10;}
		JLabel lblHabitacion = new JLabel("Habitación (MAX "+nHabs+"):");
		lblHabitacion.setFont(new Font("Tahoma", Font.PLAIN, 15));
		int widthHab = 134;
		lblHabitacion.setBounds(30, 180, widthHab, Medidas.alturaLTF);
		lblHabitacion.setForeground(Color.WHITE);
		lblHabitacion.setOpaque(true);
		lblHabitacion.setBackground(Color.DARK_GRAY);
		panelFondo.add(lblHabitacion);
		
		jTFHabitacion = new JTextField();
		jTFHabitacion.setEditable(false);
		jTFHabitacion.setBounds(195, 180, Medidas.anchuraTF, Medidas.alturaLTF);
		panelFondo.add(jTFHabitacion);
		
		JLabel lblNZombis = new JLabel("Zombis:");
		lblNZombis.setFont(new Font("Tahoma", Font.PLAIN, 15));
		int widthNZombis = 53;
		lblNZombis.setBounds(30, 210, widthNZombis, Medidas.alturaLTF);
		lblNZombis.setForeground(Color.WHITE);
		lblNZombis.setOpaque(true);
		lblNZombis.setBackground(Color.DARK_GRAY);
		panelFondo.add(lblNZombis);
		
		jTFNZombis = new JTextField();
		jTFNZombis.setEditable(false);
		jTFNZombis.setBounds(195, 210, Medidas.anchuraTF, Medidas.alturaLTF);
		panelFondo.add(jTFNZombis);
		
		jBtnLuchar = new JButton("Luchar");
		jBtnLuchar.setBounds(575, 255, Medidas.anchuraB, Medidas.alturaB);
		panelFondo.add(jBtnLuchar);
		jBtnLuchar.addActionListener(this);
		
		jBtnCurarse = new JButton("Curarse");
		jBtnCurarse.setBounds(575, 300, Medidas.anchuraB, Medidas.alturaB);
		panelFondo.add(jBtnCurarse);
		jBtnCurarse.addActionListener(this);
		
		jBtnBuscar = new JButton("Buscar");
		jBtnBuscar.setBounds(575, 345, Medidas.anchuraB, Medidas.alturaB);
		panelFondo.add(jBtnBuscar);
		jBtnBuscar.addActionListener(this);
		
		jBtnAvanzar = new JButton("Avanzar");
		jBtnAvanzar.setBounds(575, 390, Medidas.anchuraB, Medidas.alturaB);
		panelFondo.add(jBtnAvanzar);
		jBtnAvanzar.addActionListener(this);
		
		jBtnGuardar = new JButton("Guardar");
		jBtnGuardar.setBounds(575, 445, Medidas.anchuraB, Medidas.alturaB);
		panelFondo.add(jBtnGuardar);
		jBtnGuardar.addActionListener(this);
		
		/*
		 * Al cerrar la ventana, se reactivan los botones del inicio
		 */
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {
            	try {
            		VentanaInicio.activarBotones();
            	} catch (Exception ex){
            	}
            }
        });
	}
	
	/**
	 * Método para desactivar los botones
	 */
	public static void desactivarBotones()
	{
		jBtnLuchar.setEnabled(false);
		jBtnCurarse.setEnabled(false);
		jBtnBuscar.setEnabled(false);
		jBtnAvanzar.setEnabled(false);
		jBtnGuardar.setEnabled(false);
	}
	
	/**
	 * Método para activar los botones
	 */
	public static void activarBotones()
	{
		jBtnLuchar.setEnabled(true);
		jBtnCurarse.setEnabled(true);
		jBtnBuscar.setEnabled(true);
		jBtnAvanzar.setEnabled(true);
		jBtnGuardar.setEnabled(true);
	}
	
	/**
	 * Método actionPerformed con el que controlar las actiones realizadas sobre los botones
	 */
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if (e.getSource().equals(jBtnLuchar))
		{
			if (ventLucha == null || ventLucha.isVisible() == false)
			{
				JFrame propietario = new JFrame();
				propietario.setResizable(false);
				ventLucha = new VentanaLucha(propietario, "MansiónZombi - Lucha con Zombi");
				desactivarBotones();
				ventLucha.setVisible(true);
			}
		}
	}
}
