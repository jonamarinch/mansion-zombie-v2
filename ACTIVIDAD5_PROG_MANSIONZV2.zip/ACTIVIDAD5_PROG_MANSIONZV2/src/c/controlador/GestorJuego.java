package c.controlador;

/**
 * Clase que representa la gestión de los diversos elementos del Juego y sus relaciones
 */
public class GestorJuego {

}
