package b.vista;

public class Medidas {
	
	public static int alturaLTF = 19;
	public static int anchuraTF = alturaLTF*2;
	public static int alturaB = alturaLTF*2;
	public static int anchuraB = alturaLTF*6;
}
