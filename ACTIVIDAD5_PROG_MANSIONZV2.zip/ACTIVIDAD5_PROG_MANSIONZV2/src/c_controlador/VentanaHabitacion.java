package c_controlador;

import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import javax.swing.*;
import javax.swing.border.*;
import a_modelo.Dado;
import a_modelo.DatosPartida;
import a_modelo.Dificultad;
import a_modelo.RegistroHistorial;
import a_modelo.Resultado;
import b_vista.Estetica;
import b_vista.Fondo;

import java.awt.*;

/**
 * Clase que representa la ventana desde la que el jugador va a controlar sus acciones en una habitación de la mansión
 */
public class VentanaHabitacion extends JDialog implements ActionListener{
	
	/**
	 * TextField de los puntos de vida
	 */
	private static JTextField jTFPuntosV;
	/**
	 * TextField de la cantidad de protecciones
	 */
	private static JTextField jTFCantProtecc;
	/**
	 * TextField de la cantidad de armas
	 */
	private static JTextField jTFCantArmas;
	/**
	 * TextField del botiquín
	 */
	private static JTextField jTFBotiquin;
	/**
	 * TextField del número de intentos de búsqueda
	 */
	private static JTextField jTFIntentos;
	/**
	 * TextField del número de habitación
	 */
	private static JTextField jTFHabitacion;
	/**
	 * TextField del número de zombis en la habitación
	 */
	private static JTextField jTFNZombis;
	/**
	 * Botón para luchar
	 */
	private static JButton jBtnLuchar;
	/**
	 * Botón para curarse
	 */
	private static JButton jBtnCurarse;
	/**
	 * Botón para buscar
	 */
	private static JButton jBtnBuscar;
	/**
	 * Botón para avanzar
	 */
	private static JButton jBtnAvanzar;
	/**
	 * Botón para guardar partida
	 */
	private static JButton jBtnGuardar;
	/**
	 * Ventana para la lucha con un zombi
	 */
	private VentanaLucha ventLucha;

	/**
	 * Método para pruebas de la clase VentanaHabitacion
	 */
	public static void main(String[] args) {
		try {
			JFrame propietario = new JFrame();
			VentanaHabitacion dialog = new VentanaHabitacion(propietario, "Prueba", Dificultad.FÁCIL, null);
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Método para crear el Dialog
	 */
	public VentanaHabitacion(JFrame propietario, String tituloDifSelecc, Dificultad difSelecc, DatosPartida datos) {
		/*
		 * Configuraciones básicas del JDialog
		 */
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 750, 550);
        Image backgroundImage = new ImageIcon("src"+File.separator+"z_fondos"+File.separator+"2-fondo-habitacion.jpg").getImage(); // Guarda la imagen de fondo
        Fondo panelFondo = new Fondo(backgroundImage); // Crea un panel con la imagen de fondo
        setContentPane(panelFondo); // Establece el panel como el panel de contenido del JFrame
        panelFondo.setBorder(new EmptyBorder(5, 5, 5, 5));
		this.setLocationRelativeTo(null);
		panelFondo.setLayout(null);
		this.setTitle(tituloDifSelecc);
		
		/*
		 * Control dificultad del Juego
		 */
		int nHabs = 0;
		if (difSelecc == Dificultad.FÁCIL)
		{
			nHabs = 5;
		} 
		else if (difSelecc == Dificultad.MEDIO)
		{
			nHabs = 7;
		} 
		else if (difSelecc == Dificultad.DIFÍCIL)
		{
			nHabs = 10;
		}
		
		/*
		 * Elementos del JDialog
		 */
		JLabel lblPuntosV = new JLabel("Puntos de Vida:");
		Estetica.estilizarLabel(lblPuntosV, 0, 30, 30);
		panelFondo.add(lblPuntosV);
		
		jTFPuntosV = new JTextField();
		Estetica.estilizarTextField(jTFPuntosV, 0, 195, 30);
		panelFondo.add(jTFPuntosV);
		
		JLabel lblCantProtecc = new JLabel("Cantidad Protecciones:");
		Estetica.estilizarLabel(lblCantProtecc, 1, 30, 30);
		panelFondo.add(lblCantProtecc);
		
		jTFCantProtecc = new JTextField();
		Estetica.estilizarTextField(jTFCantProtecc, 1, 195, 30);
		panelFondo.add(jTFCantProtecc);
		
		JLabel lblCantArmas = new JLabel("Cantidad Armas:");
		Estetica.estilizarLabel(lblCantArmas, 2, 30, 30);
		panelFondo.add(lblCantArmas);
		
		jTFCantArmas = new JTextField();
		Estetica.estilizarTextField(jTFCantArmas, 2, 195, 30);
		panelFondo.add(jTFCantArmas);
		
		JLabel lblBotiquin = new JLabel("¿Botiquín?:");
		Estetica.estilizarLabel(lblBotiquin, 3, 30, 30);
		panelFondo.add(lblBotiquin);
		
		jTFBotiquin = new JTextField();
		Estetica.estilizarTextField(jTFBotiquin, 3, 195, 30);
		panelFondo.add(jTFBotiquin);
		
		JLabel lblIntentos = new JLabel("Intentos Búsqueda:");
		Estetica.estilizarLabel(lblIntentos, 4, 30, 30);
		panelFondo.add(lblIntentos);
		
		jTFIntentos = new JTextField();
		Estetica.estilizarTextField(jTFIntentos, 4, 195, 30);
		panelFondo.add(jTFIntentos);
		
		JLabel lblHabitacion = new JLabel("Habitación (MAX "+nHabs+"):");
		Estetica.estilizarLabel(lblHabitacion, 5, 30, 30);
		panelFondo.add(lblHabitacion);
		
		jTFHabitacion = new JTextField();
		Estetica.estilizarTextField(jTFHabitacion, 5, 195, 30);
		panelFondo.add(jTFHabitacion);
		
		JLabel lblNZombis = new JLabel("Zombis:");
		Estetica.estilizarLabel(lblNZombis, 6, 30, 30);
		panelFondo.add(lblNZombis);
		
		jTFNZombis = new JTextField();
		Estetica.estilizarTextField(jTFNZombis, 6, 195, 30);
		panelFondo.add(jTFNZombis);
		
		jBtnLuchar = new JButton("Luchar");
		Estetica.estilizarBoton(jBtnLuchar, 0, 575, 255);
		panelFondo.add(jBtnLuchar);
		jBtnLuchar.addActionListener(this);
		
		jBtnCurarse = new JButton("Curarse");
		Estetica.estilizarBoton(jBtnCurarse, 1, 575, 255);
		panelFondo.add(jBtnCurarse);
		jBtnCurarse.addActionListener(this);
		
		jBtnBuscar = new JButton("Buscar");
		Estetica.estilizarBoton(jBtnBuscar, 2, 575, 255);
		panelFondo.add(jBtnBuscar);
		jBtnBuscar.addActionListener(this);
		
		jBtnAvanzar = new JButton("Avanzar");
		Estetica.estilizarBoton(jBtnAvanzar, 3, 575, 255);
		panelFondo.add(jBtnAvanzar);
		jBtnAvanzar.addActionListener(this);
		
		jBtnGuardar = new JButton("Guardar");
		Estetica.estilizarBoton(jBtnGuardar, 4, 575, 255+10);
		panelFondo.add(jBtnGuardar);
		jBtnGuardar.addActionListener(this);
		
		/*
		 * Control carga de la partida
		 */
		if (datos != null)
		{
			actualizarDatosPartida(datos);
		}
		else if (datos == null)
		{
			GestorJuego.inicioNuevoJuego(difSelecc);
			actualizarDatosTextFields();
		}
		desactivarBotones();
		activarBotones();
		
		/*
		 * Al cerrar la ventana, se reactivan los botones del inicio
		 */
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {
            	try {
            		VentanaInicio.activarBotones();
            	} catch (Exception ex){
            	}
            }
        });
	}
	
	/**
	 * Método para actualizar los datos estáticos de la partida
	 * 
	 * @param datos Objeto con los datos a cargar de la partida
	 */
	public void actualizarDatosPartida(DatosPartida datos)
	{
		DatosPartida.setSuperv(datos.getS());
		DatosPartida.setZombi(datos.getZ());
		DatosPartida.setNumTotalZombis(datos.getNTZ());
		DatosPartida.setNumTotalHabitaciones(datos.getNTH());
		DatosPartida.setPosActualHabitaciones(datos.getPAH());
		DatosPartida.setNumIntentosBusqueda(datos.getNIB());
		
		actualizarDatosTextFields();
	}
	
	/**
	 * Método para actualizar los TextFields según los datos de la partida
	 */
	public static void actualizarDatosTextFields()
	{
		jTFPuntosV.setText(""+DatosPartida.getSuperv().getPuntosVida());
		jTFCantProtecc.setText(""+DatosPartida.getSuperv().getCantidadProtecciones());
		jTFCantArmas.setText(""+DatosPartida.getSuperv().getCantidadArmas());
		jTFBotiquin.setText(""+DatosPartida.getSuperv().isTengoBotiquin());
		jTFIntentos.setText(""+DatosPartida.getNumIntentosBusqueda());
		jTFHabitacion.setText(""+DatosPartida.getPosActualHabitaciones());
		jTFNZombis.setText(""+DatosPartida.getNumTotalZombis());
	}
	
	/**
	 * Método para desactivar los botones
	 */
	public static void desactivarBotones()
	{
		jBtnLuchar.setEnabled(false);
		jBtnCurarse.setEnabled(false);
		jBtnBuscar.setEnabled(false);
		jBtnAvanzar.setEnabled(false);
		jBtnGuardar.setEnabled(false);
	}
	
	/**
	 * Método para activar los botones
	 */
	public static void activarBotones()
	{
		if (DatosPartida.getSuperv().getPuntosVida() > 0 && DatosPartida.getNumTotalZombis() != 0) {jBtnLuchar.setEnabled(true);}
		if (DatosPartida.getSuperv().isTengoBotiquin()) {jBtnCurarse.setEnabled(true);}
		if (DatosPartida.getNumIntentosBusqueda() > 0 && DatosPartida.getNumTotalZombis() == 0) {jBtnBuscar.setEnabled(true);}
		if (DatosPartida.getNumTotalZombis() == 0) {jBtnAvanzar.setEnabled(true);}
		if (DatosPartida.getSuperv().getPuntosVida() > 0) {jBtnGuardar.setEnabled(true);}
	}
	
	/**
	 * Método actionPerformed con el que controlar las actiones realizadas sobre los botones
	 */
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if (e.getSource().equals(jBtnLuchar))
		{
			if (ventLucha == null || ventLucha.isVisible() == false)
			{
				JFrame propietario = new JFrame();
				propietario.setResizable(false);
				ventLucha = new VentanaLucha(propietario, "MansiónZombi - Lucha con Zombi");
				desactivarBotones();
				ventLucha.setVisible(true);
			}
		}
		else if (e.getSource().equals(jBtnCurarse))
		{
			if (DatosPartida.getSuperv().isTengoBotiquin() == true)
			{
				DatosPartida.getSuperv().annadirPuntosVida(4);
				if (DatosPartida.getSuperv().getPuntosVida() > DatosPartida.getSuperv().getMaxPuntosVida())
				{
					DatosPartida.getSuperv().setPuntosVida(DatosPartida.getSuperv().getMaxPuntosVida());
				}
				DatosPartida.getSuperv().setTengoBotiquin(false);
				JOptionPane.showMessageDialog(null, "Te has curado por medio de tu botiquín", "TE HAS CURADO", JOptionPane.INFORMATION_MESSAGE);
			}
			else
			{
				JOptionPane.showMessageDialog(null, "No tienes ningún botiquín para curarte", "NO HAY BOTIQUÍN", JOptionPane.ERROR_MESSAGE);
			}
			actualizarDatosTextFields();
		}
		else if (e.getSource().equals(jBtnBuscar))
		{
			Dado dado = new Dado();
			int resultBusqueda = dado.lanzarDado100();
			if (resultBusqueda <= 75)
			{
				JOptionPane.showMessageDialog(null, "¡Oh no! ¡Has hecho ruido!", "RUIDO", JOptionPane.ERROR_MESSAGE);
					resultBusqueda = dado.lanzarDado100();
					if (resultBusqueda <= 40)
					{
						JOptionPane.showMessageDialog(null, "Menos mal, no ocurrió nada", "NADA", JOptionPane.INFORMATION_MESSAGE);
					}
					else if (resultBusqueda > 40 && resultBusqueda <= 80)
					{
						JOptionPane.showMessageDialog(null, "¡Oh no! ¡Un Zombi te ha oído!", "1 ZOMBI", JOptionPane.ERROR_MESSAGE);
						DatosPartida.setNumTotalZombis(1);
						desactivarBotones();
						activarBotones();
					}
					else if (resultBusqueda > 80)
					{
						JOptionPane.showMessageDialog(null, "¡Oh no! ¡Dos Zombis te han oído!", "2 ZOMBIS", JOptionPane.ERROR_MESSAGE);
						DatosPartida.setNumTotalZombis(2);
						desactivarBotones();
						activarBotones();
					}
			}
			else if (resultBusqueda > 75 && resultBusqueda <= 90)
			{
				JOptionPane.showMessageDialog(null, "¡Genial! ¡Has encontrado un botiquín!", "BOTIQUÍN", JOptionPane.INFORMATION_MESSAGE);
				DatosPartida.getSuperv().setTengoBotiquin(true);
				desactivarBotones();
				activarBotones();
			}
			else if (resultBusqueda > 90 && resultBusqueda <= 95)
			{
				JOptionPane.showMessageDialog(null, "¡Genial! ¡Has encontrado una protección!", "PROTECCIÓN", JOptionPane.INFORMATION_MESSAGE);
				DatosPartida.getSuperv().ganarProteccion();
			}
			else if (resultBusqueda > 95)
			{
				JOptionPane.showMessageDialog(null, "¡Genial! ¡Has encontrado un arma!", "ARMA", JOptionPane.INFORMATION_MESSAGE);
				DatosPartida.getSuperv().ganarArma();
			}
			DatosPartida.restarIntentoBusqueda();
			actualizarDatosTextFields();
		}
		else if (e.getSource().equals(jBtnAvanzar))
		{
			DatosPartida.annadirPosActual();
			if (DatosPartida.getPosActualHabitaciones() > DatosPartida.getNumTotalHabitaciones())
			{
				RegistroHistorial registro = new RegistroHistorial(Resultado.VICTORIA, DatosPartida.getDificultad(), DatosPartida.getPosActualHabitaciones(), DatosPartida.getSuperv().getPuntosVida(),
						DatosPartida.getSuperv().isTengoBotiquin(), DatosPartida.getSuperv().getCantidadArmas(), DatosPartida.getSuperv().getCantidadProtecciones());
				if (VentanaHistorial.model.getRowCount() == 0)
				{
					VentanaHistorial.addColumns(VentanaHistorial.model);
				}
				VentanaHistorial.addRow(registro);
				desactivarBotones();
				JOptionPane.showMessageDialog(null, "¡HAS CONSEGUIDO ESCAPAR DE LA MANSIÓN ZOMBIE", "VICTORIA", JOptionPane.INFORMATION_MESSAGE);
			}
			else {
				GestorJuego.nuevaHabitacion();
				JOptionPane.showMessageDialog(null, "¡Has conseguido avanzar a la siguiente habitación!\n(" + DatosPartida.getPosActualHabitaciones() + " de " + DatosPartida.getNumTotalHabitaciones()+")", "AVANZAS A LA SIGUIENTE HABITACIÓN", JOptionPane.INFORMATION_MESSAGE);
			}
		}
		else if (e.getSource().equals(jBtnGuardar))
		{
			// Se van a guardar los datos del vector de objetos Libro en un fichero binario
			String pathFicheroBinario = "src"+File.separator+"z_datos"+File.separator+"PartidaGuardada.bin";
			File ficheroBinario = new File(pathFicheroBinario);
			try {
				// Apertura
				FileOutputStream flujoSalida = new FileOutputStream(ficheroBinario);
				ObjectOutputStream oos = new ObjectOutputStream(flujoSalida);
				// Escritura (vamos recorriendo el vector de objetos Libro)
				DatosPartida partidaParaGuardar = new DatosPartida(DatosPartida.getSuperv(), DatosPartida.getZombi(), DatosPartida.getNumTotalZombis(), DatosPartida.getNumTotalHabitaciones(), DatosPartida.getPosActualHabitaciones(), DatosPartida.getNumIntentosBusqueda());
				oos.writeObject(partidaParaGuardar);
				// Cierre
				flujoSalida.close();
				JOptionPane.showMessageDialog(null, "Se guardaron los datos de la partida", "PARTIDA GUARDADA", JOptionPane.INFORMATION_MESSAGE);
			} catch (IOException e1)
			{
				e1.printStackTrace();
			}
		}
	}
}
