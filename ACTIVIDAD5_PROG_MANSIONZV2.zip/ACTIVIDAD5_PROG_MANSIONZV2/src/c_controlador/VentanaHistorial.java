package c_controlador;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import a_modelo.Dificultad;
import a_modelo.RegistroHistorial;
import a_modelo.Resultado;
import b_vista.Estetica;

/**
 * Clase que representa la ventana en la que puede consultarse el historial de partidas
 */
public class VentanaHistorial extends JDialog implements ActionListener{
	
	/**
	 * ComboBox para el filtro del historial
	 */
	private JComboBox comboBox;
	/**
	 * La tabla
	 */
	private JTable table;
	/**
	 * Model de la tabla
	 */
	public static DefaultTableModel model = new DefaultTableModel();;
	private final JPanel contentPanel = new JPanel();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			JFrame propietario = new JFrame();
			propietario.setResizable(false);
			VentanaHistorial dialog = new VentanaHistorial(propietario, "Prueba");
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public VentanaHistorial(Frame propietario, String tituloDifSelecc) {
		/*
		 * Configuraciones básicas del JDialog
		 */
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 750, 550);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setLayout(new FlowLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		this.setLocationRelativeTo(null);
		contentPanel.setLayout(null);
		this.setTitle(tituloDifSelecc);
		this.setResizable(false);
		/*
		 * Añadir label y comboBox
		 */
		JLabel lblFiltro = new JLabel("Filtrar resultados:");
		Estetica.estilizarLabel(lblFiltro, 0, 10, 30);
		contentPanel.add(lblFiltro);
		
		comboBox = new JComboBox<>(Resultado.values());
		comboBox.setBounds(150, 25, 130, 30);
		contentPanel.add(comboBox);
		comboBox.addActionListener(this);
		
		/*
		 * Configuraciones básicas JTable
		 */
		table = new JTable();
		table.setBounds(10, 100, 710, 385);
		JScrollPane scroll = new JScrollPane(table);
		scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
		scroll.setBounds(10, 100, 710, 385);
	    
		// Se añade el model a la tabla
	    table.setModel(model);
	    
	    /*
	     * Se añade el Scroll a la ventana
	     */
	    contentPanel.add(scroll);
		
		/*
		 * Al cerrar la ventana, se reactivan los botones del inicio
		 */
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {
            	try {
            		VentanaInicio.activarBotones();
            	} catch (Exception ex){
            	}
            }
        });
	}
	
	/**
	 * @param model Modelo al que añadir las columnas
	 */
	public static void addColumns(DefaultTableModel model)
    {
    	model.addColumn("Resultado");
	    model.addColumn("Dificultad");
	    model.addColumn("Habitación");
	    model.addColumn("PV Restantes");
	    model.addColumn("¿Botiquín?");
	    model.addColumn("Armas");
	    model.addColumn("Protecciones");
    }
	
	/**
	 * @param registro El registro a añadir como fila
	 */
	public static void addRow(RegistroHistorial registro)
	{
		model.addRow(new Object[]{registro.getResultado(), registro.getDificultad(), registro.getHabitacion(), registro.getRestantesPV(), registro.isTeniaBotiquin(), registro.getNumArmas(), registro.getNumProtecc()});
	}
	
	/**
	 * Método actionPerformed con el que controlar las actiones realizadas sobre el ComboBox
	 */
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if (e.getSource().equals(comboBox))
		{
			DefaultTableModel nuevoModel = new DefaultTableModel();
			addColumns(nuevoModel);
			for (int i = 0; i < model.getRowCount(); i++) {
				if (model.getValueAt(i, 0) == comboBox.getSelectedItem() || comboBox.getSelectedItem() == Resultado.CUALQUIERA)
				{
					nuevoModel.addRow(new Object[]{model.getValueAt(i, 0), model.getValueAt(i, 1), model.getValueAt(i, 2), model.getValueAt(i, 3), model.getValueAt(i, 4), model.getValueAt(i, 5), model.getValueAt(i, 6)});
				}
			}
			table.setModel(nuevoModel);
		}
	}

}
