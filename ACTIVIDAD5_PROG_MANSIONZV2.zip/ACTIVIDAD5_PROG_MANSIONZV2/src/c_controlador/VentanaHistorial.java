package c_controlador;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import a_modelo.Dificultad;
import a_modelo.RegistroHistorial;
import a_modelo.Resultado;
import b_vista.Estetica;

/**
 * Clase que representa la ventana en la que puede consultarse el historial de partidas
 */
public class VentanaHistorial extends JDialog implements ActionListener{
	
	/**
	 * ComboBox para el filtro del historial
	 */
	private JComboBox comboBox;
	/**
	 * La tabla
	 */
	private JTable table;
	/**
	 * Model de la tabla
	 */
	public static DefaultTableModel model = new DefaultTableModel();
	/**
	 * JPanel
	 */
	private final JPanel contentPanel = new JPanel();

	/**
	 * Create the dialog.
	 * 
	 * @param propietario el JFrame
	 * @param titulo el título
	 */
	public VentanaHistorial(Frame propietario, String titulo) {
		/*
		 * Configuraciones básicas del JDialog
		 */
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 750, 550);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setLayout(new FlowLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		this.setLocationRelativeTo(null);
		contentPanel.setLayout(null);
		this.setTitle(titulo);
		this.setResizable(false);
		/*
		 * Añadir label y comboBox
		 */
		JLabel lblFiltro = new JLabel("Filtrar resultados:");
		Estetica.estilizarLabel(lblFiltro, 0, 10, 30);
		contentPanel.add(lblFiltro);
		
		comboBox = new JComboBox<>(Resultado.values());
		comboBox.setBounds(150, 25, 130, 30);
		contentPanel.add(comboBox);
		comboBox.addActionListener(this);
		
		/*
		 * Configuraciones básicas JTable
		 */
		table = new JTable();
		table.setBounds(10, 100, 710, 385);
		JScrollPane scroll = new JScrollPane(table);
		scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
		scroll.setBounds(10, 100, 710, 385);
	    
		// Se añade el model a la tabla
		if (model.getColumnCount() == 0)
		{
			addColumns();
		}
	    table.setModel(model);
	    
	    /*
	     * Se añade el Scroll a la ventana
	     */
	    contentPanel.add(scroll);		
	    
	    /*
		 * Cargar datos guardados si los hay
		 */
		if (isTextoEscrito())
		{
			cargarDatosGuardados();
		}
	    
		/*
		 * Al cerrar la ventana, se reactivan los botones del inicio
		 */
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {
            	try {
            		VentanaInicio.activarBotones();
            	} catch (Exception ex){
            	}
            }
        });
	}
	
	/**
	 * Método para añadir columnas al modelo
	 */
	public static void addColumns()
    {
    	model.addColumn("Resultado");
	    model.addColumn("Dificultad");
	    model.addColumn("Habitación");
	    model.addColumn("PV Restantes");
	    model.addColumn("¿Botiquín?");
	    model.addColumn("Armas");
	    model.addColumn("Protecciones");
    }
	
	/**
	 * Método para añadir columnas a un modelo auxiliar
	 * 
	 * @param modeloAux Modelo al que añadir las columnas
	 */
	public static void addColumns(DefaultTableModel modeloAux)
    {
		modeloAux.addColumn("Resultado");
		modeloAux.addColumn("Dificultad");
		modeloAux.addColumn("Habitación");
		modeloAux.addColumn("PV Restantes");
		modeloAux.addColumn("¿Botiquín?");
		modeloAux.addColumn("Armas");
		modeloAux.addColumn("Protecciones");
    }
	
	/**
	 * Método para cargar los datos guardados en un fichero de texto
	 */
	public static void cargarDatosGuardados()
	{
		try {
			BufferedReader reader = new BufferedReader(new FileReader("src"+File.separator+"z_datos"+File.separator+"historico.txt"));
			boolean sigue = true;
			String str1RES = ""; String str2DIF = ""; String str3HAB = ""; String str4PV = ""; String str5BOT = ""; String str6ARM = ""; String str7PROT = "";
			String aux = "";
			while (sigue)
				{
					aux = reader.readLine();
					if (aux == null || aux.equals(""))
					{
						if (!str1RES.equals(""))
						{
							addRow(str1RES, str2DIF, str3HAB, str4PV, str5BOT, str6ARM, str7PROT);
							str1RES = ""; str2DIF = ""; str3HAB = ""; str4PV = ""; str5BOT = ""; str6ARM = ""; str7PROT = "";
						}
						sigue = false;
					}
					else if (aux.equals("VICTORIA") || aux.equals("DERROTA"))
					{
						if (!str1RES.equals(""))
						{
							addRow(str1RES, str2DIF, str3HAB, str4PV, str5BOT, str6ARM,str7PROT);
							str2DIF = ""; str3HAB = ""; str4PV = ""; str5BOT = ""; str6ARM = ""; str7PROT = "";
						}
						str1RES = aux;
					} else if (aux.equals("FÁCIL") || aux.equals("MEDIO") || aux.equals("DIFÍCIL"))
					{
						str2DIF = aux;
					} else if (!str2DIF.equals("") && str3HAB.equals("") && str4PV.equals(""))
					{
						str3HAB = aux;
					} else if (!str3HAB.equals("") && str4PV.equals("") && str5BOT.equals(""))
					{
						str4PV = aux;
					} else if (!str4PV.equals("") && str5BOT.equals("") && str6ARM.equals(""))
					{
						str5BOT = aux;
					} else if (!str5BOT.equals("") && str6ARM.equals("") && str7PROT.equals(""))
					{
						str6ARM = aux;
					} else if (!str6ARM.equals("") && str7PROT.equals(""))
					{
						str7PROT = aux;
					}
				}
			reader.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * Método para comprobar si hay texto escrito ya
	 * 
	 * @return Devuelve si se ha escrito en el fichero binario
	 */
	public static boolean isTextoEscrito()
	{
		boolean isEscritoTexto = false;
		File file = new File("src"+File.separator+"z_datos"+File.separator+"historico.txt");
        try (FileReader fileReader = new FileReader(file)) {
            // Intentar leer un carácter del archivo
            int character = fileReader.read();
            // Si el primer carácter es -1, significa que el archivo está vacío
            return (character != -1);
            //Cerrar el BufferedReader
            
        } catch (IOException e) {
            e.printStackTrace();
        }
		return isEscritoTexto;
	}
	
	/**
	 * Método parametrizado con un objeto RegistroHistorial para añadir fila a la tabla
	 * 
	 * @param registro El registro a añadir como fila
	 */
	public static void addRow(RegistroHistorial registro)
	{
		model.addRow(new Object[]{registro.getResultado(), registro.getDificultad(), registro.getHabitacion(), registro.getRestantesPV(), registro.isTeniaBotiquin(), registro.getNumArmas(), registro.getNumProtecc()});
	}
	
	/**
	 * Método parametrizado con Strings para añadir fila a la tabla
	 * 
	 * @param str1 Resultado
	 * @param str2 Dificultad
	 * @param str3 Habitación
	 * @param str4 Puntos de vida
	 * @param str5 Botiquín
	 * @param str6 Armas
	 * @param str7 Protecciones
	 */
	public static void addRow(String str1, String str2, String str3, String str4, String str5, String str6, String str7)
	{
		model.addRow(new String[]{str1, str2, str3, str4, str5, str6, str7});
	}
	
	/**
	 * Método actionPerformed con el que controlar las actiones realizadas sobre el ComboBox
	 */
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		try {
			if (e.getSource().equals(comboBox))
			{
				DefaultTableModel nuevoModel = new DefaultTableModel();
				addColumns(nuevoModel);
				for (int i = 0; i < model.getRowCount(); i++) {
					if (model.getValueAt(i, 0).toString().equals(comboBox.getSelectedItem().toString()) || comboBox.getSelectedItem().toString().equals(Resultado.CUALQUIERA.toString()))
					{
						nuevoModel.addRow(new Object[]{model.getValueAt(i, 0), model.getValueAt(i, 1), model.getValueAt(i, 2), model.getValueAt(i, 3), model.getValueAt(i, 4), model.getValueAt(i, 5), model.getValueAt(i, 6)});
					}
				}
				table.setModel(nuevoModel);
			}
		} catch (Exception e1)
		{
		}
	}

}
