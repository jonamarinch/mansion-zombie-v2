package c_controlador;

/**
 * Clase en la que se guardan los filtros para el historial
 */
public enum FiltroHistorial {
	TODOS, DERROTAS, VICTORIAS;
}
