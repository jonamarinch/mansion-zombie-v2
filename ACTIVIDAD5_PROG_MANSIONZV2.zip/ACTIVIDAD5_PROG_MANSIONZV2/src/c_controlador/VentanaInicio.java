package c_controlador;

import java.awt.EventQueue;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import a_modelo.DatosPartida;
import a_modelo.Dificultad;
import b_vista.Fondo;

/**
 * Clase que representa la ventana de inicio desde la que se inicia el programa
 */
public class VentanaInicio extends JFrame implements ActionListener{

	/**
	 * Número de versión de serialización
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * Panel de la ventana
	 */
	private JPanel contentPane;
	/**
	 * Botón para empezar a jugar
	 */
	private static JButton button_jugar;
	/**
	 * Botón para cargar una partida guardada
	 */
	private static JButton button_cargar;
	/**
	 * Botón para ver el historial de partidas
	 */
	private static JButton button_historial;
	/**
	 * JDialog desde el que se jugará la partida
	 */
	private VentanaHabitacion ventHab;
	/**
	 * JDialog desde el que se podrá consultar el historial de partidas
	 */
	private VentanaHistorial ventHist;
	/**
	 * ComboBox en el que se seleccionará la dificultad
	 */
	private JComboBox comboBox;
	/**
	 * Dificultad seleccionada para la partida
	 */
	private Dificultad difSeleccionada;
	/**
	 * Datos para cargar de una partida
	 */
	private static DatosPartida datosPartida;

	/**
	 * Método para iniciar el programa MANSIÓN ZOMBI V2
	 * 
	 * @param args Argumentos de la línea de comandos (no utilizado en este ejemplo)
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaInicio frame = new VentanaInicio();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Método para crear el Frame
	 */
	public VentanaInicio() {
		/*
		 * Configuraciones básicas del Frame
		 */
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 750, 550);
        Image backgroundImage = new ImageIcon("src"+File.separator+"z_fondos"+File.separator+"1-fondo-inicio.jpg").getImage(); // Guarda la imagen de fondo
        Fondo panelFondo = new Fondo(backgroundImage); // Crea un panel con la imagen de fondo
        setContentPane(panelFondo); // Establece el panel como el panel de contenido del JFrame
        this.setResizable(false);
        /*
        // Pon música
        // Musica musica = new Musica():*/
        panelFondo.setBorder(new EmptyBorder(5, 5, 5, 5));
		this.setLocationRelativeTo(null);
		panelFondo.setLayout(null);
		
		/*
		 * Elementos del Frame
		 */
		button_jugar = new JButton("Jugar");
		button_jugar.setBounds(185, 120, 180, 40);
		panelFondo.add(button_jugar);
		button_jugar.addActionListener(this);
		
		button_cargar = new JButton("Cargar Partida");
		button_cargar.setBounds(185, 220, 180, 40);
		panelFondo.add(button_cargar);
		button_cargar.addActionListener(this);
		
		button_historial = new JButton("Ver Histórico");
		button_historial.setBounds(185, 320, 180, 40);
		panelFondo.add(button_historial);
		button_historial.addActionListener(this);
		
		comboBox = new JComboBox<>(Dificultad.values());
		comboBox.setBounds(395, 125, 130, 30);
		panelFondo.add(comboBox);
	}
	
	/**
	 * Método para desactivar los botones
	 */
	public static void desactivarBotones()
	{
		button_jugar.setEnabled(false);
		button_cargar.setEnabled(false);
		button_historial.setEnabled(false);
	}
	
	/**
	 * Método para activar los botones
	 */
	public static void activarBotones()
	{
		button_jugar.setEnabled(true);
		button_cargar.setEnabled(true);
		button_historial.setEnabled(true);
	}
	
	/**
	 * Método para cargar datos guardados de una partida
	 */
	public static void cargarDatosPartida()
	{
		
	}
	
	/**
	 * Método actionPerformed con el que controlar las actiones realizadas sobre los botones
	 */
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if (e.getSource().equals(button_jugar))
		{
			if (ventHab == null || ventHab.isVisible() == false)
			{
				difSeleccionada = (Dificultad) comboBox.getSelectedItem();
				JFrame propietario = new JFrame();
				propietario.setResizable(false);
				ventHab = new VentanaHabitacion(propietario, "MansiónZombi - Partida - "+difSeleccionada, difSeleccionada, null);
				desactivarBotones();
				ventHab.setVisible(true);
			}
		} else if (e.getSource().equals(button_cargar))
		{
			if (ventHab == null || ventHab.isVisible() == false)
			{
				cargarDatosPartida();
				difSeleccionada = (Dificultad) comboBox.getSelectedItem();
				JFrame propietario = new JFrame();
				propietario.setResizable(false);
				ventHab = new VentanaHabitacion(propietario, "MansiónZombi - Partida - "+difSeleccionada, difSeleccionada, datosPartida);
				desactivarBotones();
				ventHab.setVisible(true);
			}
		} else if (e.getSource().equals(button_historial))
		{
			if (ventHist == null || ventHist.isVisible() == false)
			{
				JFrame propietario = new JFrame();
				propietario.setResizable(false);
				ventHist = new VentanaHistorial(propietario, "Historial");
				desactivarBotones();
				ventHist.setVisible(true);
			}
		}
	}

}
