package c_controlador;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.*;

import a_modelo.DatosPartida;
import b_vista.Estetica;
import b_vista.Fondo;

public class VentanaLucha extends JDialog implements ActionListener{
	
	/**
	 * TextArea en el que mostrar al usuario lo que ocurre en el programa
	 */
	public static JTextArea textArea;
	/**
	 * Botón para luchar con el zombi
	 */
	private static JButton botonLuchar;
	/**
	 * Botón para continuar
	 */
	private static JButton botonContinuar;
	/**
	 * TextField para los puntos de vida del jugador
	 */
	private static JTextField jTFJugPV;
	private static JTextField jTFJugPA;
	private static JTextField jTFZomPV;
	private static JTextField jTFZomPA;

	/**
	 * Lanzar la aplicación
	 */
	public static void main(String[] args) {
		try {
			JFrame propietario = new JFrame();
			propietario.setResizable(false);
			VentanaLucha dialog = new VentanaLucha(propietario, "Prueba");
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Crear el diálogo
	 */
	public VentanaLucha(JFrame propietario, String tituloDifSelecc) {
		/*
		 * Configuraciones básicas del JDialog
		 */
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 750, 550);
        Image backgroundImage = new ImageIcon("src"+File.separator+"z_fondos"+File.separator+"3-fondo-lucha-b.jpg").getImage(); // Guarda la imagen de fondo
        Fondo panelFondo = new Fondo(backgroundImage); // Crea un panel con la imagen de fondo
        setContentPane(panelFondo); // Establece el panel como el panel de contenido del JFrame
        panelFondo.setBorder(new EmptyBorder(5, 5, 5, 5));
		this.setLocationRelativeTo(null);
		panelFondo.setLayout(null);
		this.setTitle(tituloDifSelecc);
		
		/*
		 * Elementos del JDialog
		 */
		textArea = new JTextArea();
		Estetica.estilizarTextArea(textArea);
		JScrollPane scrollPane = new JScrollPane(textArea); // Se mete en un JScrollPane para que se pueda hacer scroll
		scrollPane.setBounds(textArea.getBounds());
		panelFondo.add(scrollPane);
		
		botonLuchar = new JButton("Luchar");
		Estetica.estilizarBoton(botonLuchar, 0, 310, 285);
		panelFondo.add(botonLuchar);
		botonLuchar.addActionListener(this);
		
		botonContinuar = new JButton("Continuar");
		Estetica.estilizarBoton(botonContinuar, 1, 310, 285);
		botonContinuar.setEnabled(false);
		panelFondo.add(botonContinuar);
		botonContinuar.addActionListener(this);
		
		JLabel lblJugPV = new JLabel("Jugador PV:");
		Estetica.estilizarLabel(lblJugPV, 0, 15, 22);
		panelFondo.add(lblJugPV);
		
		JLabel lblJugPA = new JLabel("Jugador ATK:");
		Estetica.estilizarLabel(lblJugPA, 1, 15, 22);
		panelFondo.add(lblJugPA);
		
		JLabel lblZomPV = new JLabel("Zombi PV:");
		Estetica.estilizarLabel(lblZomPV, 2, 15, 22);
		lblZomPV.setBorder(Estetica.getBorderZombi());
		panelFondo.add(lblZomPV);
		
		JLabel lblZomPA = new JLabel("Zombi ATK:");
		Estetica.estilizarLabel(lblZomPA, 3, 15, 22);
		lblZomPA.setBorder(Estetica.getBorderZombi());
		panelFondo.add(lblZomPA);
		
		jTFJugPV = new JTextField();
		Estetica.estilizarTextField(jTFJugPV, 0, 135, 22);
		panelFondo.add(jTFJugPV);
		
		jTFJugPA = new JTextField();
		Estetica.estilizarTextField(jTFJugPA, 1, 135, 22);
		panelFondo.add(jTFJugPA);
		
		jTFZomPV = new JTextField();
		Estetica.estilizarTextField(jTFZomPV, 2, 135, 22);
		panelFondo.add(jTFZomPV);
		
		jTFZomPA = new JTextField();
		Estetica.estilizarTextField(jTFZomPA, 3, 135, 22);
		panelFondo.add(jTFZomPA);
		
		/*
		 * Control del inicio de la Lucha
		 */
		GestorJuego.inicioNuevaLucha();
		actualizarTextFields();
		JOptionPane.showMessageDialog(null, "Te enfrentarás contra el Zombi. Mucha suerte, la necesitas.", "LUCHA CONTRA EL ZOMBI", JOptionPane.INFORMATION_MESSAGE);

		/**
		 * Método para que, al cerrar la ventana, se reactivan los botones del inicio
		 */
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {
            	try {
            		VentanaHabitacion.activarBotones();
            	} catch (Exception ex){
            	}
            }
        });
	}
	
	/**
	 * Método para actualizar los TextFields
	 */
	public static void actualizarTextFields()
	{
		jTFJugPV.setText(""+DatosPartida.getSuperv().getPuntosVida());
		jTFJugPA.setText(""+DatosPartida.getSuperv().getPuntosAtaque());
		jTFZomPV.setText(""+DatosPartida.getZombi().getPuntosVida());
		jTFZomPA.setText(""+DatosPartida.getZombi().getPuntosAtaque());
		
	}
	
	public static void actualizarBotones()
	{
		if (DatosPartida.getSuperv().getPuntosVida() > 0 && DatosPartida.getZombi().getPuntosVida() > 0)
		{
			botonLuchar.setEnabled(true);
			botonContinuar.setEnabled(false);
		}
		else if (DatosPartida.getSuperv().getPuntosVida() > 0 && DatosPartida.getZombi().getPuntosVida() <= 0)
		{
			botonLuchar.setEnabled(false);
			botonContinuar.setEnabled(true);
		}
		else if (DatosPartida.getSuperv().getPuntosVida() <= 0 && DatosPartida.getZombi().getPuntosVida() > 0)
		{
			botonLuchar.setEnabled(false);
			botonContinuar.setEnabled(false);
		}
	}
	
	/**
	 * Método para anunciar la victoria
	 */
	public static void victoria()
	{
		JOptionPane.showMessageDialog(null, "Mataste al Zombi", "VICTORIA", JOptionPane.INFORMATION_MESSAGE);
	}
	
	/**
	 * Método para anunciar la derrota
	 */
	public static void derrota()
	{
		JOptionPane.showMessageDialog(null, "El Zombi te mató", "DERROTA", JOptionPane.INFORMATION_MESSAGE);
	}
	
	/**
	 * Método actionPerformed con el que controlar las actiones realizadas sobre los botones
	 */
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if (e.getSource().equals(botonLuchar))
		{
			GestorJuego.turnoAtaque();
		}
		else if (e.getSource().equals(botonContinuar))
		{
			VentanaHabitacion.actualizarDatosTextFields();
			this.dispose();
		}
	}
}
