package c_controlador;

import a_modelo.Dado;
import a_modelo.DatosPartida;
import a_modelo.Dificultad;
import a_modelo.Superviviente;
import a_modelo.Zombi;

/**
 * Clase que representa la gestión de los diversos elementos del Juego y sus relaciones
 */
public class GestorJuego {
	
	/**
	 * Objeto Dado
	 */
	Dado dado;
	
	/**
	 * Método para iniciar un nuevo juego y actualizar los datos
	 * 
	 * @param difSelecc Recibe la Dificultad seleccionada
	 */
	public static void inicioNuevoJuego(Dificultad difSelecc)
	{
		/*
		 * Nuevo superviviente
		 */
		Superviviente superv = new Superviviente();
		/*
		 * Control dificultad del Juego
		 */
		int nHabs = 0;
		if (difSelecc == Dificultad.FÁCIL)
		{
			nHabs = 5;
		} 
		else if (difSelecc == Dificultad.MEDIO)
		{
			nHabs = 7;
		} 
		else if (difSelecc == Dificultad.DIFÍCIL)
		{
			nHabs = 10;
		}
		/*
		 * Almacenar datos de la nueva partida
		 */
		DatosPartida.setNumTotalHabitaciones(nHabs);
		DatosPartida.setSuperv(superv);
		DatosPartida.setNumTotalZombis(1);
		DatosPartida.setPosActualHabitaciones(1);
		DatosPartida.setNumIntentosBusqueda(3);
	}
	
	public static void nuevaHabitacion()
	{
		DatosPartida.setNumIntentosBusqueda(3);
		DatosPartida.setNumTotalZombis(1);
		VentanaHabitacion.actualizarDatosTextFields();
		VentanaHabitacion.desactivarBotones();
		VentanaHabitacion.activarBotones();
	}
	
	/**
	 * Método para gestionar el inicio de una nueva Lucha con un Zombi
	 */
	public static void inicioNuevaLucha()
	{
		/*
		 * Nuevo Zombi
		 */
		Dado dado = new Dado();
		Zombi zombi = new Zombi(dado.randomPuntosZombi(DatosPartida.getPosActualHabitaciones()), dado.randomPuntosZombi(DatosPartida.getPosActualHabitaciones()));
		/*
		 * Almacenar Zombi
		 */
		DatosPartida.setZombi(zombi);
	}
	
	/**
	 * Método para gestionar cada turno de ataque
	 */
	public static void turnoAtaque()
	{
		int ronda = 1;
			VentanaLucha.textArea.append(">>>>> RONDA: "+ronda+"\n");
			int ataqueSuperv = DatosPartida.getSuperv().atacar();
			VentanaLucha.textArea.append("> Atacas con "+ataqueSuperv+" ("+(ataqueSuperv-DatosPartida.getSuperv().getCantidadArmas())+" de ataque + "+DatosPartida.getSuperv().getCantidadArmas()+" de armas)"+"\n");
			DatosPartida.getZombi().restarPuntosVida(ataqueSuperv);
			if (DatosPartida.getZombi().getPuntosVida() > 0) 
			{
				int ataqueZombi = DatosPartida.getZombi().atacar();
				DatosPartida.getSuperv().restarPuntosVida(ataqueZombi-DatosPartida.getSuperv().getCantidadProtecciones());
				VentanaLucha.textArea.append("> El Zombi ataca con "+ataqueZombi+"\n");
			}
			VentanaLucha.actualizarTextFields();
			VentanaLucha.actualizarBotones();
			VentanaHabitacion.actualizarDatosTextFields();
		if (DatosPartida.getZombi().getPuntosVida() <= 0)
		{
			DatosPartida.setZombi(null);
			DatosPartida.restarNumTotalZombis();
			VentanaLucha.victoria();
		}
		else if (DatosPartida.getSuperv().getPuntosVida() <= 0)
		{
			VentanaLucha.derrota();
		}
	}
}
