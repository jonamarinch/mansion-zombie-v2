package acciones;

import java.util.Scanner;

import personajes.Superv;
import main.Habitacion;

public class Botiquin {
	
	public void usarBotiquin(Println notificaciones, Superv superviviente) {
		
		superviviente.usoBotiquin();
		notificaciones.usoBotiquin(superviviente.getPuntosVida());
	}
}