package acciones;

import java.util.Scanner;

import main.Habitacion;
import personajes.Superv;
import personajes.Zombi;
import main.Fin;

public class Lucha {
	
	public void combate(Println notificaciones, Scanner teclado, Superv superviviente, 
			Menu sn, Habitacion habit, Dado dado, Fin fin) {
		
	//Aquí aparece el Zombi
	Zombi z = new Zombi(dado, habit);
	int ComprobarNZombis = habit.GetNZombies();
	habit.setNZombis(1);
	if (ComprobarNZombis == 2) {
		habit.setNZombis(2);
	}
	notificaciones.apareceZombi(z.getPuntosVida(), z.getPuntosAtaque());
	notificaciones.statusTotal(superviviente.getNombre(), superviviente.getPuntosVida(), superviviente.getPuntosAtaque(),
			superviviente.getBotiquin(), superviviente.getArmas(), superviviente.getProteccion());
	
	while(true) {
		
		// Aquí ataco al Zombi
		notificaciones.atacarZombi();
		int atacarZombi = sn.dosOpciones(teclado, notificaciones);
			
			if(atacarZombi==1) {
				int tiradaSuperv = dado.tirarDado(superviviente.getPuntosAtaque());
				z.setPuntosVida(tiradaSuperv, superviviente.getArmas());
				notificaciones.statusLucha1(tiradaSuperv, superviviente.getArmas(), z.getPuntosVida());
			}	
			else if(atacarZombi==2) {
				fin.ejecutarFinVoluntario(notificaciones);
			}
		
		// Si matamos al Zombi, el número de Zombis disminuye en 1
		if (z.getPuntosVida() <= 0) {
			notificaciones.matasteUnZombi();
			habit.menosNZombis(1);
			
			// Si aún así nos sigue quedando un Zombi, el Zombi se regenera (es como si apareciese otro Zombi)
			if (habit.GetNZombies() == 1 && z.getPuntosVida() <= 0) {
				z.regenerar(dado, habit);
				notificaciones.apareceZombi(z.getPuntosVida(), z.getPuntosAtaque());
				continue;
			}
		}
		
		// Si sólo había 1 Zombi y lo hemos matado, ya está todo hecho
		if (z.getPuntosVida() <= 0 && habit.GetNZombies() == 0) {
			notificaciones.matasteZombi();
			break;
		}
		
		//Aquí el Zombi me ataca a mí
		notificaciones.atacado();
		
		int tiradaZombi = dado.tirarDado(z.getPuntosAtaque());
		superviviente.setPuntosVida(tiradaZombi, superviviente.getProteccion());
		notificaciones.statusLucha2(superviviente.getPuntosVida(), superviviente.getProteccion(), tiradaZombi);
		
		//
		
		// Si muero, todo termina
		if (superviviente.getPuntosVida() <= 0) {
			fin.ejecutarFinTrasMuerte(notificaciones);
		}
		
	}
}
}