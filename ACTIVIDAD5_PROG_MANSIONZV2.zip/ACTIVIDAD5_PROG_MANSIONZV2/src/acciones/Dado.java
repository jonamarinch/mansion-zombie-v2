package acciones;

import java.util.Random;

public class Dado {
	
	Random tirada = new Random();
	
	public int Dos() {
		return (tirada.nextInt(2)+1);
	}
	
	public int tirarDado(int puntos) {
		puntos++;
		return tirada.nextInt(puntos);
	}
	
	public int Busqueda() {
		return tirada.nextInt(101);
	}
}