package acciones;

import java.util.Scanner;


public class Menu {
	
	public int dosOpciones(Scanner teclado, Println notificaciones) {
		
		int resultado = 0;
		boolean respondido = false;
		while (respondido == false) {
			try {
				String respuesta = teclado.next();
				
					if (respuesta.equals("1")) {
						respondido = true;
						resultado = 1;
						break; 
					}
					else if (respuesta.equals("2")) {
						respondido = true;
						resultado = 2;
						break; 
					}
					else if (!respuesta.equals("")){
						respondido = false;
						notificaciones.exception();
					}
			}
			
			catch (Exception e){
				respondido = false;
				notificaciones.exception();
			}
		}
		return resultado;
	}
	
	public int unaOpcion(Scanner teclado, Println notificaciones) {
		
		int resultado = 0;
		boolean respondido = false;
		while (respondido == false) {
			try {
				String respuesta = teclado.next();
				
					if (respuesta.equals("1")) {
						respondido = true;
						resultado = 1;
						break; 
					}
					else if (!respuesta.equals("")){
						respondido = false;
						notificaciones.exception();
						teclado.nextLine();
					}
			}
			
			catch (Exception e) {
				respondido = false;
				notificaciones.exception();
				teclado.nextLine();
			}
		}
		return resultado;
	}
	
	public int tresOpciones(Scanner teclado, Println notificaciones) {
		
		int resultado = 0;
		boolean respondido = false;
		while (respondido == false) {
			try {
				String respuesta = teclado.next();
				
					if (respuesta.equals("1")) {
						respondido = true;
						resultado = 1;
						break;
					}
					else if (respuesta.equals("2")) {
						respondido = true;
						resultado = 2;
						break;
					}
					else if (respuesta.equals("3")) {
						respondido = true;
						resultado = 3;
						break;
					}
					else if (!respuesta.equals("")){
						respondido = false;
						notificaciones.exception();
						teclado.nextLine();
					}
			}
			
			catch (Exception e) {
				respondido = false;
				notificaciones.exception();
				teclado.nextLine();
			}
		}
		return resultado;
	}
}