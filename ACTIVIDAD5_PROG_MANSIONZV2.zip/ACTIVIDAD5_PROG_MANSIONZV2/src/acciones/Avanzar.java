package acciones;

import main.Habitacion;
import personajes.Superv;

public class Avanzar {
	
	public void sigHabitacion(Habitacion mansion, Println notificaciones, Superv superviviente) {
		mansion.SetHabitacion();
		//mansion.setNZombis(1);
		notificaciones.continuar();
	}
	
}