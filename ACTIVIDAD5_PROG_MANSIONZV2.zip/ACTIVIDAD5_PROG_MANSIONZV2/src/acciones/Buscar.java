package acciones;

import java.util.Scanner;

import personajes.Superv;
import main.Habitacion;
import main.Fin;

public class Buscar {
	
	public void ejecutarBusqueda(Println notificaciones, Scanner teclado, Dado dado, 
			Superv superviviente, Menu sn, Habitacion mansion, Botiquin botiquin, Fin fin, Lucha lucha) {
		int d = dado.Busqueda();
		
		if (d < 40) {
			notificaciones.buscarNada();
		}
		
		if (d >= 40 && d < 76) {
			mansion.masNZombis(dado.Dos());
			notificaciones.hechoRuido(mansion.GetNZombies());
			lucha.combate(notificaciones, teclado, superviviente, sn, mansion, dado, fin);
		}
		
		if (d >= 76 && d <= 90) {
			superviviente.ganoBotiquin();
			notificaciones.botGanado();
		}
		
		if (d >= 91 && d <= 95) {
			superviviente.ganoProteccion();
			notificaciones.protGanada();
		}
		
		if (d >= 96) {
			superviviente.ganoArmas();
			notificaciones.armasGanadas();
		}
		
		mansion.UsarBusquedas();
	}
}