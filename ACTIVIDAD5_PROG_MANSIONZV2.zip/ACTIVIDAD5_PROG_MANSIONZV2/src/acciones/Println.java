package acciones;

public class Println {

// Aviso de por dónde voy
	public void status(String nombre, int habitacion, int numHabs) {
		System.out.println("\n****************************************************\n" 
				+ nombre + ", AHORA TE ENCUENTRAS EN LA HABITACIÓN " 
				+ habitacion + " DE " + numHabs + "\n");
	}

// Aviso de todas las propiedades del superviviente
	public void statusTotal(String nombre, int PV, int PA, boolean botiq, int armas, int prot) {
		System.out.println("\n" + nombre + " estos son tus datos:\n\n"
				+ "Puntos de vida -> " + PV + "\n"
				+ "Puntos de Ataque -> " + PA + "\n"
				+ "Botiquín -> " + botiq + "\n"
				+ "Armas -> " + armas + "\n"
				+ "Protecciones -> " + prot + "\n");
	}
	
// Aviso de cómo va la lucha
	public void statusLucha1(int tusPA, int Armas, int zPV) {
		System.out.println("\nHaces una ataque de " + tusPA + " puntos," + " que con tus " + Armas + " armas, son en total " + (tusPA + Armas)
		+ " así que al final le dejas al Zombi con: " + zPV + " Puntos de Vida\n");
	}
	
// Aviso de cómo va la lucha
	public void statusLucha2(int tusPV, int prot, int zPA) {
		System.out.println("\nEl Zombi hace un ataque de " + zPA + " puntos, y tu tienes " + prot + " protecciones"
		+ " así que al final te deja con: " + tusPV + " Puntos de Vida\n");
	}

// Primer Menú
	public void primerMenu(String nombre, int nBusq) {
		System.out.println("\nMuy bien, " + nombre + ",tienes " + nBusq + " búsquedas" + " y por ello estas opciones...\n"
				+ "1 -> Avanzar a la siguiente habitación\n");
	}
	
	// Segundo Menú
		public void segundoMenu(String nombre) {
			System.out.println("\n" + nombre + ", ahora tienes las siguientes opciones...\n"
					+ "1 -> Avanzar a la siguiente habitación\n"
					+ "2 -> Buscar primero en la habitación actual antes de avanzar\n");
		}
	
	// Tercer Menú
		public void tercerMenu(String nombre) {
			System.out.println("\nMuy bien, " + nombre + ", ahora tienes las siguientes opciones...\n"
					+ "1 -> Avanzar a la siguiente habitación\n"
					+ "2 -> Curarse con un botiquín\n");
		}
		
	// Cuarto Menú
		public void cuartoMenu(String nombre) {
			System.out.println("\nMuy bien, " + nombre + ", ahora tienes las siguientes opciones...\n"
					+ "1 -> Avanzar a la siguiente habitación\n"
					+ "2 -> Buscar primero en la habitación actual antes de avanzar\n"
					+ "3 -> Curarse con un botiquín");
		}

// y|n para seguir o huir
	public void seguirHuir() {
		System.out.println("\n1 -> Seguir con el juego\n"
				+ "2 -> Huir cobardemente\n");
	}
	
// y|n para continuar o buscar
	public void listoBotiquin() {
		System.out.println("\n¿Quieres \n"
				+ "1 -> Avanzar directamente a la siguiente habitación\n"
				+ "2 -> Utilizar el botiquín\n");
	}
	
// Busco y no pasa nada
	public void buscarNada() {
		System.out.println("\nNo has encontrado nada en la habitación pero al menos no te han oído\n");
	}
	
// Has hecho ruido
	public void hechoRuido(int NZombis) {
		System.out.println("\n¡Oh, no! ¡Has hecho RUIDO!\n"
				+ "Has sido oído y ha entrado en la habitación este número de Zombis: " + NZombis + "\n");
	}
	
// Has ganado un botiquín 
	public void botGanado() {
		System.out.println("\nHas tenido suerte y encontrado un botiquín\n");
	}
	
// Has ganado una protección
	public void protGanada() {
		System.out.println("\nHas tenido suerte y encontrado una protección\n");
	}
	
// Has ganado armas
	public void armasGanadas() {
		System.out.println("\nHas tenido suerte y encontrado armas\n");
	}
	
// continuar
	public void continuar() {
		System.out.println("\nHas avanzado a la siguiente habitación\n");
	}
	
// Aviso de que no se ha hecho una selección válida
	public void exception() {
		System.out.println("\n¿No eres capaz de elegir una opción válida?\n"
				+ "Los zombis son menos tontos que tú...\n"
				+ "A ver, prueba otra vez...\n");
	}
	
// Aviso para elegir dificultad
	public void dificultad() {
		System.out.println("\nBienvenido, te recomendamos ejecutar el juego con espacio suficiente en pantalla para visualizarlo todo\n\n" 
				+ "¿Qué dificultad eliges para la MANSIÓN ZOMBI?\n"
				+ "1 -> modo FÁCIL\n"
				+ "2 -> modo DIFÍCIL\n");
	}

// Has elegido el modo fácil
	public void facil() {
		System.out.println("\nEstás jugando en modo FÁCIL...\n"
				+ "Tendrás que superar tan sólo 5 HABITACIONES para escapar de la MANSIÓN...\n"
				+ "Quizá de esta forma puedas sobrevivir...\n");
	}
	
// Has elegido el modo difícil
	public void dificil() {
		System.out.println("\nEstás jugando en modo DIFÍCIL...\n"
				+ "Tendrás que superar 10 HABITACIONES para escapar de la MANSIÓN...\n"
				+ "Yo te daría por muerto...\n");
	}
	
// Aviso para elegir nombre
	public void eligeNombre() {
		System.out.println("\nAhora elige tu nombre:");
	}
	
// y|n para entrar en la Mansión Zombi
	public void listoMansion(String nombre) {
		System.out.println("\nMuy bien, " + nombre + ", avísame cuando estés listo para viajar a la MANSIÓN ZOMBI...\n"
				+ "Puedes huir también, sería lo más inteligente que has hecho hasta ahora...\n"
				+ "1 -> Entrar en la mansión cual valiente aventurero\n"
				+ "2 -> Huir cobardemente\n");
	}
	
// Efecto viaje a la Mansión Zombi
	public void viajeMansion() {
		for (int it = 0; it < 150; it++) {
			System.out.println("****************");
		}
	}

// Mensaje llegada a la Mansión Zombi
	public void llegadaMansion(String nombre) {
		System.out.println("\nHas entrado en la MANSIÓN ZOMBI... Buena suerte, " + nombre + "... \n");
	}
	
// Mensaje de que ha aparecido un Zombi
	public void apareceZombi(int PVZombi, int PAZombi) {
	System.out.println("\n¡¡Hay un Zombi!!\n"
			+ "El Zombi tiene " + PVZombi + " Puntos de Vida.\n"
			+ "También tiene " + PAZombi + " Puntos de Ataque.\n");
	}
	
// Mensaje para atacar al Zombi
	public void atacarZombi() {
		System.out.println("\n¡¡Para avanzar deberás luchar con el Zombi!! Para luchar con el Zombi pulsa 1\n");
		seguirHuir();
	}
	
// Mensaje por haber matado a todos los Zombis
	public void matasteZombi() {
		System.out.println("\n¡¡Muy bien, ya no queda ningún Zombi en la habitación!!\n");
	}
	
// Mensaje por haber matado un Zombi
	public void matasteUnZombi() {
		System.out.println("\n¡¡Muy bien, mataste un Zombi!!\n");
	}
	
// Mensaje por ser atacado
	public void atacado() {
		System.out.println("\nAhora el ZOMBI te atacará a ti\n");
	}
	
// Mensaje fin juego voluntario
	public void finVoluntario() {
		System.out.println("\nUna pena, los zombis se quedarán sin merienda. Pero entiendo que quieras huir ahora que estás a tiempo...\n");
	}
	
// Mensaje fin tras muerte
	public void finTrasMuerte() {
		System.out.println("\nHas sufrido una muerte cruenta y dolorosa. No digas que no te avisé...\n");
	}
	
// Mensaje fin tras victoria
	public void finVictoria(String nombre) {
		System.out.println("\nENHORABUENA " + nombre + ", HAS ESCAPADO DE LA MANSIÓN ZOMBI.\n\n"
				+ "Autor del juego:\n"
				+ "Jonathan Marín 1ºDAM");
	}

// Devolver número de Zombis
	public void numZombis(int numZombis) {
		System.out.println("\nNúmero de Zombis: " + numZombis + "\n");
	}
	
// Uso Botiquín
	public void usoBotiquin(int puntosVida) {
		System.out.println("\nHas usado un botiquín\n"
				+ "Ahora tienes: " + puntosVida + " puntos de vida\n");
	}
}