package a.modelo;

/**
 * Clase que representa al usuario que tendrá que atravesar la Mansión Zombi
 */
public class Superviviente extends Personaje{
	
	/**
	 * Número máximo de puntos de vida del superviviente
	 */
	private final int NUM_MAX_PUNTOS_VIDA;
	
	/**
	 * Buleano que indica si el superviviente tiene botiquín o no
	 */
	private boolean tengoBotiquin;
	
	/**
	 * Cantidad de armas que tiene el superviviente
	 */
	private int cantidadArmas;
	
	/**
	 * Cantidad de protecciones que tiene el superviviente
	 */
	private int cantidadProtecciones;
	
	/**
	 * Constructor por defecto del Superviviente
	 */
	public Superviviente()
	{
		this.NUM_MAX_PUNTOS_VIDA = 20;
		this.setPuntosVida(NUM_MAX_PUNTOS_VIDA);
		this.setPuntosAtaque(4);
		this.tengoBotiquin = false;
		this.cantidadArmas = 0;
		this.cantidadProtecciones = 0;
	}
	
	/**
	 * Getter que indica si el superviviente tiene botiquín o no
	 * 
	 * @return Devuelve el dato de tipo lógico correspondiente
	 */
	public boolean isTengoBotiquin() {
		return tengoBotiquin;
	}
	
	/**
	 * Setter que da o quita el botiquín al superviviente
	 * 
	 * @param tengo Recibe un buleano que indica si se da o quita el botiquín al superviviente
	 */
	public void setTengoBotiquin(boolean tengo)
	{
		this.tengoBotiquin = tengo;
	}
	
	/**
	 * Getter de la cantidad de armas del superviviente
	 * 
	 * @return Devuelve la cantidad de armas del superviviente
	 */
	public int getCantidadArmas() {
		return cantidadArmas;
	}
	
	/**
	 * Método para aumentar en 1 la cantidad de armas del superviviente
	 */
	public void ganarArma()
	{
		this.cantidadArmas++;
	}
	
	/**
	 * Getter de la cantidad de protecciones del superviviente
	 * 
	 * @return Devuelve la cantidad de protecciones del superviviente
	 */
	public int getCantidadProtecciones() {
		return cantidadProtecciones;
	}
	
	/**
	 * Método para aumentar en 1 la cantidad de protecciones del superviviente
	 */
	public void ganarProtecciones()
	{
		this.cantidadProtecciones++;
	}
}
