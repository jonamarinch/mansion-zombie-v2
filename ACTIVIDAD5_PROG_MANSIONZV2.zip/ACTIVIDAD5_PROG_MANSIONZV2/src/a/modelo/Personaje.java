package a.modelo;

/**
 * Clase abstracta que heredarán tanto 'zombi' como 'usuario'
 */
public abstract class Personaje {
	
	/**
	 * Puntos de vida del personaje
	 */
	private int puntosVida;
	/**
	 * Puntos de ataque del personaje
	 */
	private int puntosAtaque;
	
	/**
	 * Getter de los puntos de vida
	 * 
	 * @return Devuelve los puntos de vida
	 */
	public int getPuntosVida() {
		return puntosVida;
	}
	
	/**
	 * Setter de los puntos de vida
	 * 
	 * @param puntosVida Recibe los puntos de vida a establecer
	 */
	public void setPuntosVida(int puntosVida) {
		this.puntosVida = puntosVida;
	}
	
	/**
	 * Getter de los puntos de ataque
	 * 
	 * @return Devuelve los puntos de ataque
	 */
	public int getPuntosAtaque() {
		return puntosAtaque;
	}
	
	/**
	 * Setter de los puntos de ataque
	 * 
	 * @param puntosVida Recibe los puntos de ataque a establecer
	 */
	public void setPuntosAtaque(int puntosAtaque) {
		this.puntosAtaque = puntosAtaque;
	}

}
